# Training on Kaggle: Complete Guide

## Overview
This guide explains how to train your federated learning project on Kaggle, including setup, adaptations, and considerations.

---

## Part 1: Kaggle Environment Setup

### Step 1: Upload Project to Kaggle

#### Option A: Upload as Dataset
1. Go to [kaggle.com](https://kaggle.com)
2. Navigate to **Datasets** → **Create** → **Upload files**
3. Create a new dataset titled `nuclei-fyp-project`
4. Upload your entire project directory as a ZIP file:
   ```powershell
   # On your local machine, compress the project
   Compress-Archive -Path "c:\Users\OP\New folder\nuclei_fyp_project" -DestinationPath "nuclei_fyp_project.zip"
   ```
5. Upload the ZIP file
6. Set visibility to **Private**
7. Click **Create** to publish

#### Option B: Use Kaggle API (Recommended)
1. Install Kaggle CLI:
   ```bash
   pip install kaggle
   ```
2. Download API token from kaggle.com → Settings → API → Create New Token
3. Place `kaggle.json` in `~/.kaggle/` directory
4. Create and push dataset:
   ```bash
   kaggle datasets create -p "c:\Users\OP\New folder\nuclei_fyp_project" --dir-mode tar
   ```

### Step 2: Create a Kaggle Notebook

1. Go to Kaggle → **Notebooks** → **+ New Notebook**
2. Choose **Python** as language
3. Add your dataset as input:
   - Click **+ Add input** → Select your uploaded dataset
4. Title it: `Federated Learning Nuclei Training`

---

## Part 2: Adapted Code for Kaggle

### Issue 1: Subprocess Limitations
Kaggle doesn't allow proper subprocess orchestration. **Solution**: Use a modified training script.

Create `kaggle_training.py` (add to `/federated/` folder):

```python
"""
Modified training script for Kaggle environment
Runs federated learning without subprocess orchestration
"""

import os
import sys
import torch
import numpy as np
from pathlib import Path
from collections import OrderedDict

# Add paths
project_root = Path('/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')
sys.path.insert(0, str(project_root))

from models.model import MultiTaskUNet
from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer
from federated.federated_utils import (
    DiceLoss, ClassificationMetrics, SegmentationMetrics,
    average_weights
)
from federated.client import FederatedLearningClient, create_client_datasets
import flwr as fl


def train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8,
    learning_rate=0.001
):
    """
    Federated training without subprocess (Kaggle-compatible)
    """
    
    print("=" * 70)
    print("FEDERATED LEARNING TRAINING ON KAGGLE")
    print("=" * 70)
    
    # Initialize global model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    global_model = MultiTaskUNet(
        in_channels=3,
        out_channels_seg=1,
        out_channels_cls=4,
        depth=4
    ).to(device)
    
    print(f"Global Model Parameters: {sum(p.numel() for p in global_model.parameters()):,}")
    
    # Generate synthetic data
    print("\n[Step 1] Generating synthetic H&E images...")
    generator = SyntheticHEImageGenerator(image_size=256)
    
    # Generate training data for each client
    client_data = []
    for client_id in range(num_clients):
        print(f"  Generating data for Client {client_id + 1}...")
        images, seg_masks, cls_labels = generator.generate_dataset(
            num_images=30,
            tissue_type_dist=[0.3, 0.2, 0.3, 0.2]  # Tumor, Inflammatory, Stroma, Necrosis
        )
        client_data.append({
            'images': images,
            'seg_masks': seg_masks,
            'cls_labels': cls_labels,
            'client_id': client_id
        })
    
    # Initialize normalizer
    print("[Step 2] Initializing stain normalizer...")
    normalizer = ReinhardNormalizer()
    reference_images = client_data[0]['images'][:10]
    normalizer.fit(reference_images)
    
    # Training loop
    print(f"\n[Step 3] Starting Federated Training ({num_rounds} rounds)...")
    print("-" * 70)
    
    # Get initial model weights
    global_weights = [p.cpu().detach().numpy() for p in global_model.parameters()]
    
    for round_num in range(1, num_rounds + 1):
        print(f"\n>>> ROUND {round_num}/{num_rounds}")
        
        client_weights_list = []
        round_metrics = {'seg_dice': [], 'cls_acc': []}
        
        # Train each client locally
        for client_id in range(num_clients):
            print(f"  Client {client_id + 1} training...")
            
            # Create client dataset
            from utils.image_processing import HistologyDataset
            import albumentations as A
            from albumentations.pytorch import ToTensorV2
            
            # Normalize client data
            norm_images = normalizer.normalize_batch(client_data[client_id]['images'])
            
            # Create dataset and loader
            augmentation = A.Compose([
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.Rotate(limit=90, p=0.5),
                A.GaussNoise(p=0.3),
                A.Normalize(mean=[0.5]*3, std=[0.5]*3),
                ToTensorV2(),
            ], is_check_shapes=False)
            
            dataset = HistologyDataset(
                norm_images,
                client_data[client_id]['seg_masks'],
                client_data[client_id]['cls_labels'],
                augmentation=augmentation
            )
            
            loader = torch.utils.data.DataLoader(
                dataset,
                batch_size=batch_size,
                shuffle=True
            )
            
            # Set model weights
            params = list(global_model.parameters())
            for param, weight in zip(params, global_weights):
                param.data = torch.from_numpy(weight).to(device)
            
            # Local training
            optimizer = torch.optim.Adam(global_model.parameters(), lr=learning_rate)
            seg_loss_fn = DiceLoss()
            cls_loss_fn = torch.nn.CrossEntropyLoss()
            
            global_model.train()
            for epoch in range(num_epochs):
                epoch_loss = 0.0
                for batch_idx, (images, seg_masks, cls_labels) in enumerate(loader):
                    images = images.to(device)
                    seg_masks = seg_masks.to(device)
                    cls_labels = cls_labels.to(device)
                    
                    optimizer.zero_grad()
                    
                    seg_out, cls_out = global_model(images)
                    
                    seg_loss = seg_loss_fn(seg_out, seg_masks)
                    cls_loss = cls_loss_fn(cls_out, cls_labels)
                    loss = seg_loss + 0.5 * cls_loss
                    
                    loss.backward()
                    optimizer.step()
                    
                    epoch_loss += loss.item()
                
                avg_loss = epoch_loss / len(loader)
                print(f"    Epoch {epoch + 1}/{num_epochs}: Loss = {avg_loss:.4f}")
            
            # Extract updated weights
            client_weights = [p.cpu().detach().numpy() for p in global_model.parameters()]
            client_weights_list.append(client_weights)
            
            # Evaluate on client data
            global_model.eval()
            with torch.no_grad():
                seg_pred, cls_pred = [], []
                for images, seg_masks, cls_labels in loader:
                    images = images.to(device)
                    seg_out, cls_out = global_model(images)
                    seg_pred.append((seg_out > 0.5).cpu().numpy())
                    cls_pred.append(cls_out.argmax(1).cpu().numpy())
                
                seg_metric = SegmentationMetrics()
                dice = seg_metric.dice_coefficient(
                    np.vstack(seg_pred),
                    client_data[client_id]['seg_masks']
                )
                
                cls_metric = ClassificationMetrics()
                acc = cls_metric.accuracy(
                    np.hstack(cls_pred),
                    client_data[client_id]['cls_labels']
                )
                
                round_metrics['seg_dice'].append(dice)
                round_metrics['cls_acc'].append(acc)
                
                print(f"    Segmentation Dice: {dice:.4f}")
                print(f"    Classification Acc: {acc:.4f}")
        
        # Server-side aggregation (FedAvg)
        print(f"\n  Aggregating {num_clients} client weights...")
        global_weights = average_weights(client_weights_list)
        
        # Print round summary
        avg_dice = np.mean(round_metrics['seg_dice'])
        avg_acc = np.mean(round_metrics['cls_acc'])
        print(f"  Round {round_num} Summary - Avg Dice: {avg_dice:.4f}, Avg Acc: {avg_acc:.4f}")
    
    # Save trained model
    print("\n[Step 4] Saving trained model...")
    output_dir = Path('/kaggle/working/models')
    output_dir.mkdir(exist_ok=True)
    
    params = list(global_model.parameters())
    for param, weight in zip(params, global_weights):
        param.data = torch.from_numpy(weight).to(device)
    
    torch.save(global_model.state_dict(), output_dir / 'trained_model.pth')
    print(f"Model saved to: {output_dir / 'trained_model.pth'}")
    
    print("\n" + "=" * 70)
    print("FEDERATED TRAINING COMPLETED SUCCESSFULLY")
    print("=" * 70)
    
    return global_model


if __name__ == "__main__":
    model = train_federated_kaggle(
        num_rounds=3,
        num_clients=2,
        num_epochs=2,
        batch_size=8,
        learning_rate=0.001
    )
```

---

## Part 3: Kaggle Notebook Cells

### Cell 1: Setup and Imports
```python
!pip install -q torch torchvision torchaudio
!pip install -q flwr
!pip install -q scikit-image scikit-learn albumentations
!pip install -q opencv-python

import os
import sys
import torch
import numpy as np
from pathlib import Path

# Add project to path
project_path = '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project'
sys.path.insert(0, project_path)

print(f"PyTorch Version: {torch.__version__}")
print(f"GPU Available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU Name: {torch.cuda.get_device_name(0)}")
```

### Cell 2: Run Training
```python
from federated.kaggle_training import train_federated_kaggle

# Run federated training
model = train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8,
    learning_rate=0.001
)
```

### Cell 3: Visualize Results
```python
import matplotlib.pyplot as plt
from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer

# Generate test data
generator = SyntheticHEImageGenerator(image_size=256)
test_images, test_seg_masks, test_cls_labels = generator.generate_dataset(num_images=5)

# Normalize
normalizer = ReinhardNormalizer()
normalizer.fit(test_images[:3])
norm_images = normalizer.normalize_batch(test_images)

# Inference
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device).eval()

with torch.no_grad():
    for i, img in enumerate(norm_images):
        img_tensor = torch.from_numpy(img).unsqueeze(0).float().to(device)
        seg_out, cls_out = model(img_tensor)
        
        seg_pred = (seg_out[0, 0].cpu().numpy() > 0.5).astype(np.uint8) * 255
        cls_pred = cls_out[0].argmax().cpu().item()
        
        tissue_names = ['Tumor', 'Inflammatory', 'Stroma', 'Necrosis']
        
        fig, axes = plt.subplots(1, 3, figsize=(15, 5))
        axes[0].imshow(img.transpose(1, 2, 0))
        axes[0].set_title('Original Image')
        axes[1].imshow(seg_pred, cmap='gray')
        axes[1].set_title('Segmentation Mask')
        axes[2].imshow(test_seg_masks[i], cmap='gray')
        axes[2].set_title('Ground Truth')
        
        plt.suptitle(f'Sample {i+1} - Predicted Tissue: {tissue_names[cls_pred]}')
        plt.tight_layout()
        plt.show()
```

---

## Part 4: Kaggle-Specific Considerations

### A. Computational Resources
- **Free Tier**: 30 hours/week GPU (usually P100 or TPU)
- **Pro Tier**: 40 hours/week GPU + more memory
- **Recommended Settings for Free Tier**:
  ```python
  num_rounds=3        # Reduce rounds
  num_clients=2       # Keep clients small
  num_epochs=2        # Fewer local epochs
  batch_size=8        # Smaller batches
  ```

### B. Memory Management
Kaggle notebooks have limited memory. If you run out:
```python
import gc
torch.cuda.empty_cache()
gc.collect()
```

### C. Data Handling

**Option 1: Use Synthetic Data (Recommended)**
- No upload needed
- Fully reproducible
- Privacy-preserving
- Use `SyntheticHEImageGenerator` as in the script above

**Option 2: Upload Real Data**
1. Create Kaggle dataset with your images
2. Reference in notebook:
   ```python
   import os
   data_path = '/kaggle/input/your-dataset-name/'
   image_files = os.listdir(data_path)
   ```

### D. Output Handling

Save results to `/kaggle/working/` for download:
```python
output_path = Path('/kaggle/working')
torch.save(model.state_dict(), output_path / 'federated_model.pth')

# Save metrics CSV
import pandas as pd
metrics_df = pd.DataFrame(all_metrics)
metrics_df.to_csv(output_path / 'training_metrics.csv', index=False)
```

---

## Part 5: Complete Kaggle Notebook Template

### Full Single-Cell Solution
```python
# Complete Federated Learning Training on Kaggle

# Setup
!pip install -q torch torchvision torchaudio flwr scikit-image scikit-learn albumentations opencv-python

import os
import sys
import torch
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from collections import OrderedDict

# Add project to path
project_path = '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project'
sys.path.insert(0, project_path)

from models.model import MultiTaskUNet
from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer
from utils.image_processing import HistologyDataset
from federated.federated_utils import (
    DiceLoss, ClassificationMetrics, SegmentationMetrics,
    average_weights
)
import albumentations as A
from albumentations.pytorch import ToTensorV2

# Configuration
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
NUM_ROUNDS = 3
NUM_CLIENTS = 2
NUM_EPOCHS = 2
BATCH_SIZE = 8
LR = 0.001

print(f"Device: {DEVICE}")
print(f"Rounds: {NUM_ROUNDS}, Clients: {NUM_CLIENTS}, Epochs: {NUM_EPOCHS}")

# Initialize model
global_model = MultiTaskUNet(
    in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4
).to(DEVICE)

print(f"Model Parameters: {sum(p.numel() for p in global_model.parameters()):,}")

# Generate data and train
print("\nGenerating synthetic data...")
generator = SyntheticHEImageGenerator(image_size=256)
client_data = [
    {
        'images': generator.generate_dataset(30)[0],
        'seg_masks': generator.generate_dataset(30)[1],
        'cls_labels': generator.generate_dataset(30)[2],
        'id': i
    }
    for i in range(NUM_CLIENTS)
]

# Initialize normalizer
normalizer = ReinhardNormalizer()
normalizer.fit(client_data[0]['images'][:10])

# Training
print("\nStarting federated training...")
global_weights = [p.cpu().detach().numpy() for p in global_model.parameters()]

all_metrics = []

for round_num in range(1, NUM_ROUNDS + 1):
    print(f"\n=== Round {round_num}/{NUM_ROUNDS} ===")
    
    client_weights_list = []
    round_metrics = []
    
    for client_id in range(NUM_CLIENTS):
        print(f"Client {client_id + 1} training...")
        
        # Prepare data
        norm_images = normalizer.normalize_batch(client_data[client_id]['images'])
        
        augmentation = A.Compose([
            A.HorizontalFlip(p=0.5),
            A.VerticalFlip(p=0.5),
            A.Normalize(mean=[0.5]*3, std=[0.5]*3),
            ToTensorV2(),
        ], is_check_shapes=False)
        
        dataset = HistologyDataset(
            norm_images,
            client_data[client_id]['seg_masks'],
            client_data[client_id]['cls_labels'],
            augmentation=augmentation
        )
        loader = torch.utils.data.DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
        
        # Set weights
        for param, weight in zip(global_model.parameters(), global_weights):
            param.data = torch.from_numpy(weight).to(DEVICE)
        
        # Train
        optimizer = torch.optim.Adam(global_model.parameters(), lr=LR)
        seg_loss_fn = DiceLoss()
        cls_loss_fn = torch.nn.CrossEntropyLoss()
        
        for epoch in range(NUM_EPOCHS):
            global_model.train()
            for images, seg_masks, cls_labels in loader:
                images = images.to(DEVICE)
                seg_masks = seg_masks.to(DEVICE)
                cls_labels = cls_labels.to(DEVICE)
                
                optimizer.zero_grad()
                seg_out, cls_out = global_model(images)
                loss = seg_loss_fn(seg_out, seg_masks) + 0.5 * cls_loss_fn(cls_out, cls_labels)
                loss.backward()
                optimizer.step()
        
        # Extract weights
        client_weights_list.append([p.cpu().detach().numpy() for p in global_model.parameters()])
        
        # Evaluate
        global_model.eval()
        with torch.no_grad():
            seg_preds, cls_preds = [], []
            for images, _, _ in loader:
                images = images.to(DEVICE)
                seg_out, cls_out = global_model(images)
                seg_preds.append((seg_out > 0.5).cpu().numpy())
                cls_preds.append(cls_out.argmax(1).cpu().numpy())
            
            seg_metric = SegmentationMetrics()
            dice = seg_metric.dice_coefficient(np.vstack(seg_preds), client_data[client_id]['seg_masks'])
            
            cls_metric = ClassificationMetrics()
            acc = cls_metric.accuracy(np.hstack(cls_preds), client_data[client_id]['cls_labels'])
            
            round_metrics.append({'client': client_id, 'dice': dice, 'acc': acc})
            print(f"  Dice: {dice:.4f}, Acc: {acc:.4f}")
    
    # Aggregate
    global_weights = average_weights(client_weights_list)
    all_metrics.extend(round_metrics)
    
    print(f"Round {round_num} aggregation complete")

# Save results
print("\nSaving results...")
output_dir = Path('/kaggle/working')
output_dir.mkdir(exist_ok=True)

for param, weight in zip(global_model.parameters(), global_weights):
    param.data = torch.from_numpy(weight).to(DEVICE)

torch.save(global_model.state_dict(), output_dir / 'federated_model.pth')
pd.DataFrame(all_metrics).to_csv(output_dir / 'metrics.csv', index=False)

print("✓ Training complete!")
print(f"✓ Model saved to /kaggle/working/federated_model.pth")
print(f"✓ Metrics saved to /kaggle/working/metrics.csv")
```

---

## Part 6: Common Kaggle Issues & Solutions

### Issue 1: "Module not found" Error
**Problem**: Imported modules not found
**Solution**:
```python
import sys
sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')
```

### Issue 2: GPU Out of Memory
**Problem**: CUDA out of memory error
**Solution**:
```python
# Reduce batch size
BATCH_SIZE = 4  # Instead of 8

# Or clear cache
torch.cuda.empty_cache()
import gc
gc.collect()
```

### Issue 3: Timeout (>9 hour limit)
**Problem**: Training takes too long
**Solution**:
```python
# Reduce computation
NUM_ROUNDS = 2      # Instead of 5
NUM_CLIENTS = 1     # Instead of 2
NUM_EPOCHS = 1      # Instead of 3
```

### Issue 4: Data Size Too Large
**Problem**: Can't upload large dataset
**Solution**: Use synthetic data instead
```python
# No real data needed!
generator = SyntheticHEImageGenerator()
```

---

## Part 7: Recommended Kaggle Training Path

### Fastest (5-10 minutes):
```python
train_federated_kaggle(
    num_rounds=2,
    num_clients=1,
    num_epochs=1,
    batch_size=16
)
```

### Balanced (15-20 minutes):
```python
train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8
)
```

### Best Quality (30-45 minutes):
```python
train_federated_kaggle(
    num_rounds=5,
    num_clients=3,
    num_epochs=3,
    batch_size=8
)
```

---

## Part 8: Useful Kaggle Commands

### Download Results Locally
```bash
kaggle kernels output USERNAME/NOTEBOOK-SLUG -p ./kaggle_results/
```

### Make Notebook Public (for sharing)
```bash
kaggle kernels push -k USERNAME/NOTEBOOK-SLUG
```

### View Training Logs
Kaggle stores logs in the notebook output. Download the notebook to review.

---

## Summary: Steps to Train on Kaggle

1. **Upload dataset** (if using real data)
   ```bash
   kaggle datasets create -p "path/to/project"
   ```

2. **Create notebook** on kaggle.com with dataset as input

3. **Copy kaggle_training.py** into `/federated/` folder before uploading

4. **Run cells** in order:
   - Setup and imports
   - Training (using modified script)
   - Visualization
   - Download results

5. **Download outputs** from `/kaggle/working/`
   - `federated_model.pth` - Trained model
   - `metrics.csv` - Training metrics

---

## Expected Results

- **Training Time**: 5-45 minutes (depending on configuration)
- **Segmentation Dice**: 0.70-0.85
- **Classification Accuracy**: 0.75-0.90
- **Model Size**: ~8.5 MB
- **Privacy**: ✓ All data stays local, only weights exchanged

