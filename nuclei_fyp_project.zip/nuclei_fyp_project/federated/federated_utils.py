"""
Federated Learning Utilities for Privacy-Preserving Training.

This module provides:
1. Loss functions: Dice Loss (segmentation) and Cross-Entropy (classification)
2. Metrics computation: Dice Coefficient, AJI, Jaccard Index
3. Model serialization/deserialization for federated updates
4. Privacy-aware training utilities

Privacy Note:
Only model weights are exchanged during federated learning.
Training data never leaves local clients - only gradient updates are aggregated.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple, List, Dict , Union
from collections import OrderedDict


# ==================== Loss Functions ====================

class DiceLoss(nn.Module):
    """
    Dice Loss for semantic segmentation.
    
    Dice coefficient = 2*|X∩Y| / (|X| + |Y|)
    Loss = 1 - Dice coefficient
    
    More robust than cross-entropy for imbalanced segmentation tasks.
    """
    
    def __init__(self, smooth: float = 1.0, epsilon: float = 1e-7):
        """
        Initialize Dice Loss.
        
        Args:
            smooth: Smoothing constant to avoid division by zero
            epsilon: Small value to prevent numerical issues
        """
        super(DiceLoss, self).__init__()
        self.smooth = smooth
        self.epsilon = epsilon
    
    def forward(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Compute Dice Loss.
        
        Args:
            predictions: Model predictions (B, 1, H, W), values in [0, 1]
            targets: Ground truth masks (B, 1, H, W), values in [0, 1]
            
        Returns:
            Scalar Dice loss
        """
        # Convert logits to probabilities if needed
        predictions = torch.sigmoid(predictions)

        # Flatten predictions and targets
        predictions_flat = predictions.contiguous().view(-1)
        targets_flat = targets.contiguous().view(-1)
        
        # Compute intersection and union
        intersection = (predictions_flat * targets_flat).sum()
        union = predictions_flat.sum() + targets_flat.sum()
        
        # Compute Dice coefficient
        dice = (2.0 * intersection + self.smooth) / (union + self.smooth + self.epsilon)
        
        # Return loss (1 - Dice)
        return 1.0 - dice


class FocalLoss(nn.Module):
    """
    Focal Loss for handling class imbalance.
    
    Focal Loss = -α * (1 - p)^γ * log(p)
    
    Useful for classification when nuclei classes are imbalanced.
    """
    
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        """
        Initialize Focal Loss.
        
        Args:
            alpha: Weighting factor in [0, 1]
            gamma: Focusing parameter γ ≥ 0
        """
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
    
    def forward(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Compute Focal Loss.
        
        Args:
            predictions: Model logits (B, num_classes)
            targets: Ground truth labels (B,)
            
        Returns:
            Scalar focal loss
        """
        # Compute cross entropy
        ce = F.cross_entropy(predictions, targets, reduction='none')
        
        # Compute probability of true class
        p = torch.exp(-ce)
        
        # Compute focal loss
        focal = self.alpha * ((1 - p) ** self.gamma) * ce
        
        return focal.mean()


class CombinedLoss(nn.Module):
    """
    Combined loss for multi-task learning.

    This model performs TWO tasks simultaneously:
    1️⃣ Segmentation (predict nucleus class for every pixel)
    2️⃣ Classification (predict tissue type for the whole image)

    Total Loss = λ_seg * SegmentationLoss + λ_cls * ClassificationLoss

    We use CrossEntropyLoss for both tasks because:
    - Segmentation is multi-class (6 nucleus classes in PanNuke)
    - Classification is multi-class (4 tissue types)
    """

    def __init__(self, lambda_seg: float = 1.0, lambda_cls: float = 0.5):
        """
        Initialize Combined Loss.

        Args:
            lambda_seg: Weight for segmentation loss
            lambda_cls: Weight for classification loss
        """

        super(CombinedLoss, self).__init__()

        # Weight factors to balance the importance of each task
        self.lambda_seg = lambda_seg
        self.lambda_cls = lambda_cls

        # Segmentation loss
        # CrossEntropyLoss expects:
        # predictions → (B, C, H, W)
        # targets     → (B, H, W)
        # where C = number of segmentation classes (6 for PanNuke)
        self.seg_loss = nn.CrossEntropyLoss()

        # Classification loss
        # predictions → (B, num_classes)
        # targets     → (B)
        self.cls_loss = nn.CrossEntropyLoss()

    def forward(
        self,
        seg_predictions: torch.Tensor,
        seg_targets: torch.Tensor,
        cls_predictions: torch.Tensor,
        cls_targets: torch.Tensor
    ):
        """
        Compute total multi-task loss.

        Args:
            seg_predictions: Segmentation logits from model
                             Shape → (B, 6, H, W)

            seg_targets: Ground truth segmentation masks
                         Shape → (B, H, W)

            cls_predictions: Classification logits
                             Shape → (B, num_classes)

            cls_targets: Ground truth class labels
                         Shape → (B)

        Returns:
            total_loss: Combined weighted loss
            loss_dict: Dictionary containing individual losses for logging
        """

        # -----------------------------
        # Segmentation Loss
        # -----------------------------
        # Measures how well the model predicts pixel-wise nucleus classes
        seg_loss = self.seg_loss(seg_predictions, seg_targets)

        # -----------------------------
        # Classification Loss
        # -----------------------------
        # Measures how well the model predicts tissue type
        cls_loss = self.cls_loss(cls_predictions, cls_targets)

        # -----------------------------
        # Total Multi-task Loss
        # -----------------------------
        total_loss = self.lambda_seg * seg_loss + self.lambda_cls * cls_loss

        # Store losses for logging/monitoring during training
        loss_dict = {
            "total_loss": total_loss.item(),
            "seg_loss": seg_loss.item(),
            "cls_loss": cls_loss.item()
        }

        return total_loss, loss_dict


# ==================== Metrics ====================

class SegmentationMetrics:
    """Compute metrics for segmentation tasks."""

    @staticmethod
    def dice_coefficient(prediction: np.ndarray, target: np.ndarray) -> float:
        """
        Compute Dice Coefficient for multi-class segmentation.
        """

        # Convert logits to predicted class map
        prediction = np.argmax(prediction, axis=0)

        prediction = prediction.astype(np.float32)
        target = target.astype(np.float32)

        intersection = np.sum(prediction == target)
        dice = (2.0 * intersection) / (prediction.size + target.size + 1e-7)

        return float(dice)

    @staticmethod
    def jaccard_index(prediction: np.ndarray, target: np.ndarray) -> float:
        """
        Compute Jaccard Index (IoU).
        """

        prediction = np.argmax(prediction, axis=0).astype(np.float32)
        target = target.astype(np.float32)

        intersection = np.sum(prediction == target)
        union = prediction.size + target.size - intersection

        return float(intersection / (union + 1e-7))

    @staticmethod
    def aji(prediction: np.ndarray, target: np.ndarray) -> float:
        """
        Compute Aggregated Jaccard Index (AJI).
        """

        return SegmentationMetrics.jaccard_index(prediction, target)


class ClassificationMetrics:
    """Compute metrics for classification tasks."""
    
    @staticmethod
    def accuracy(predictions: np.ndarray, targets: np.ndarray) -> float:
        return float(np.mean(predictions == targets))
    
    @staticmethod
    def confusion_matrix(predictions: np.ndarray, targets: np.ndarray, num_classes: int = 19) -> np.ndarray:
        cm = np.zeros((num_classes, num_classes), dtype=np.int32)
        for pred, target in zip(predictions, targets):
            cm[target, pred] += 1
        return cm
    
    @staticmethod
    def per_class_accuracy(cm: np.ndarray) -> np.ndarray:
        return np.diag(cm) / (cm.sum(axis=1) + 1e-7)


# ==================== Model Serialization ====================

def model_to_weights(model: nn.Module) -> Dict[str, np.ndarray]:
    """
    Convert model parameters to dictionary of numpy arrays.
    """
    return {name: param.detach().cpu().numpy() for name, param in model.state_dict().items()}


def weights_to_model(model: nn.Module, weights: Dict[str, np.ndarray]) -> nn.Module:
    """
    Load weights from dictionary into model.
    """
    state_dict = OrderedDict()
    for name, weight in weights.items():
        state_dict[name] = torch.from_numpy(weight)
    
    model.load_state_dict(state_dict, strict=True)
    return model


def get_model_size(model: nn.Module) -> int:
    """
    Get total size of model in bytes.
    """
    return sum(p.nelement() * p.element_size() for p in model.parameters())

""" old version of average_weights for reference:
def average_weights(weight_list: List[Dict[str, np.ndarray]]) -> Dict[str, np.ndarray]:
    
    #Average multiple weight dictionaries (FedAvg operation).
    
    averaged = {}
    num_clients = len(weight_list)
    
    for name in weight_list[0].keys():
        averaged[name] = sum(w[name] for w in weight_list) / num_clients
    
    return averaged
"""
# new version of average_weights that supports both list of arrays and dicts:
def average_weights(weight_list: List[Union[List[np.ndarray], Dict[str, np.ndarray]]]):
    # Averages weights from multiple clients (supports both list of arrays and OrderedDict).
    if not weight_list:
        return None
    
    num_clients = len(weight_list)
    if isinstance(weight_list[0], dict):
        averaged = OrderedDict()
        for name in weight_list[0].keys():
            averaged[name] = sum(w[name] for w in weight_list) / num_clients
        return averaged
    else:
        averaged = []
        for i in range(len(weight_list[0])):
            layer_weights = [client[i] for client in weight_list]
            averaged.append(np.mean(layer_weights, axis=0))
        return averaged