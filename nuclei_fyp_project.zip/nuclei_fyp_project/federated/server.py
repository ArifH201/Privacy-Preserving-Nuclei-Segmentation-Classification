"""
Federated Learning Server using Flower Framework.

Server-side implementation of FedAvg algorithm:
1. Receives model updates from clients
2. Averages weights (FedAvg operation)
3. Broadcasts global model back to clients
4. Evaluates on server-side test set

PRIVACY GUARANTEE:
- Server never accesses raw training data from clients
- Only receives aggregated model weights
- Gradient information is processed distributively
"""

import os
import sys
from pathlib import Path
from typing import Tuple, List, Dict
import argparse

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

# Add parent directory to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from models.model import create_model
from federated.federated_utils import (
    weights_to_model,
    SegmentationMetrics,
    ClassificationMetrics,
    CombinedLoss
)
from utils.mock_data_generator import generate_mock_dataset

import flwr as fl
from flwr.server import ServerConfig
from flwr.server.strategy import FedAvg
from flwr.common import parameters_to_ndarrays


# ==================== Server Functions ====================

def evaluate_model(
    model: nn.Module,
    test_loader: DataLoader,
    device: torch.device
) -> Tuple[float, Dict[str, float]]:
    """
    Evaluate model on test set.
    
    Args:
        model: Model to evaluate
        test_loader: DataLoader for test data
        device: Device to run evaluation on
        
    Returns:
        (loss, metrics_dict) tuple
    """
    model.eval()
    total_loss = 0.0
    dice_scores = []
    cls_accuracies = []
    
    criterion = CombinedLoss()
    
    with torch.no_grad():
        for batch in test_loader:
            images = batch[0].to(device)
            masks = batch[1].to(device)
            labels = batch[2].to(device)
            
            # Forward pass
            seg_output, cls_output = model(images)
            
            # Compute loss
            loss, _ = criterion(seg_output, masks, cls_output, labels)
            total_loss += loss.item()
            
            # Compute metrics
            seg_pred = seg_output.cpu().numpy()
            seg_target = masks.cpu().numpy()
            
            for pred, target in zip(seg_pred, seg_target):
                dice = SegmentationMetrics.dice_coefficient(pred, target)
                dice_scores.append(dice)
            
            # Classification accuracy
            cls_pred = cls_output.argmax(dim=1).cpu().numpy()
            cls_target = labels.cpu().numpy()
            acc = ClassificationMetrics.accuracy(cls_pred, cls_target)
            cls_accuracies.append(acc)
    
    avg_loss = total_loss / len(test_loader)
    avg_dice = np.mean(dice_scores) if dice_scores else 0.0
    avg_acc = np.mean(cls_accuracies) if cls_accuracies else 0.0
    
    metrics = {
        'test_loss': avg_loss,
        'test_dice': avg_dice,
        'test_accuracy': avg_acc
    }
    
    return avg_loss, metrics


def create_test_loader(
    test_images: List[np.ndarray],
    test_masks: List[np.ndarray],
    test_labels: List[int],
    batch_size: int = 4,
    device: torch.device = torch.device('cpu')
) -> DataLoader:
    """
    Create test DataLoader from numpy arrays.
    
    Args:
        test_images: List of test images
        test_masks: List of test masks
        test_labels: List of test labels
        batch_size: Batch size for evaluation
        device: Device to load data on
        
    Returns:
        DataLoader for testing
    """
    # Convert to tensors
    images_tensor = torch.from_numpy(np.array(test_images)).float()
    images_tensor = images_tensor.permute(0, 3, 1, 2)  # NHWC -> NCHW
    images_tensor = images_tensor / 255.0  # Normalize to [0, 1]
    
    masks_tensor = torch.from_numpy(np.array(test_masks)).float()
    masks_tensor = masks_tensor.unsqueeze(1)  # Add channel dimension
    masks_tensor = masks_tensor / 255.0  # Normalize to [0, 1]
    
    labels_tensor = torch.from_numpy(np.array(test_labels)).long()
    
    dataset = TensorDataset(images_tensor, masks_tensor, labels_tensor)
    return DataLoader(dataset, batch_size=batch_size, shuffle=False)


# ==================== Custom Strategy ====================

class FedAvgWithEvaluation(FedAvg):
    """
    Custom FedAvg strategy with server-side evaluation.
    
    Adds evaluation on server-side test set after each round.
    """
    
    def __init__(self, model: nn.Module, test_loader: DataLoader, device: torch.device, *args, **kwargs):
        """
        Initialize strategy.
        
        Args:
            model: Model to evaluate
            test_loader: Test data loader
            device: Device for evaluation
        """
        super().__init__(*args, **kwargs)
        self.model = model
        self.test_loader = test_loader
        self.device = device
        self.evaluation_results = []
    
    def aggregate_fit(self, rnd: int, results, failures):
        """
        Aggregate and evaluate after each round.
        
        Args:
            rnd: Current round number
            results: Results from clients
            failures: Failed clients
            
        Returns:
            Aggregated weights and metrics
        """
        aggregated = super().aggregate_fit(rnd, results, failures)

        if aggregated is None:
            return None

        parameters, metrics = aggregated

        # Convert Flower parameters to numpy arrays
        ndarrays = parameters_to_ndarrays(parameters)

        # Convert list back to state_dict
        state_dict = {}
        for key, value in zip(self.model.state_dict().keys(), ndarrays):
            state_dict[key] = torch.tensor(value)

        # Update model
        self.model = weights_to_model(self.model, state_dict)
        self.model.to(self.device)

        # Evaluate on server test set
        loss, eval_metrics = evaluate_model(self.model, self.test_loader, self.device)

        print(f"\n[SERVER] Round {rnd} Evaluation:")
        print(f"  Loss: {loss:.4f}")
        print(f"  Dice Score: {eval_metrics['test_dice']:.4f}")
        print(f"  Classification Accuracy: {eval_metrics['test_accuracy']:.4f}")

        self.evaluation_results.append({
            'round': rnd,
            'loss': loss,
            'metrics': eval_metrics
        })

        return parameters, metrics


# ==================== Main Function ====================

def main(args):
    """Run federated learning server."""
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[SERVER] Using device: {device}")
    
    # Create global model
    global_model = create_model().to(device)
    print(f"[SERVER] Global model created with {global_model.get_parameter_count():,} parameters")
    
    # Generate or load test data
    print("[SERVER] Generating test dataset...")
    test_images, test_masks, test_labels = generate_mock_dataset(
        output_dir=None,  # Don't save to disk
        num_samples_per_class=3
    )
    
    # Create test loader
    test_loader = create_test_loader(test_images, test_masks, test_labels, batch_size=4)
    
    # Define FedAvg strategy with evaluation
    strategy = FedAvgWithEvaluation(
        model=global_model,
        test_loader=test_loader,
        device=device,
        fraction_fit=1.0,
        fraction_evaluate=1.0,
        min_fit_clients=args.min_fit_clients,
        min_evaluate_clients=args.min_evaluate_clients,
        min_available_clients=args.min_available_clients,
        initial_parameters=None,
    )
    
    # Create server configuration
    config = ServerConfig(
        num_rounds=args.num_rounds,
        round_timeout=600
    )
    
    print(f"\n[SERVER] Starting Federated Learning with:")
    print(f"  - Number of rounds: {args.num_rounds}")
    print(f"  - Min fit clients: {args.min_fit_clients}")
    print(f"  - Min evaluate clients: {args.min_evaluate_clients}")
    print(f"  - Server address: {args.server_address}")
    
    # Start server
    fl.server.start_server(
        server_address=args.server_address,
        config=config,
        strategy=strategy,
        certificates=(
            str(Path("server.crt")),
            str(Path("server.key")),
            str(Path("ca.crt"))
        ) if args.use_ssl else None
    )
    
    # Save final model
    os.makedirs('models', exist_ok=True)
    torch.save(strategy.model.state_dict(), 'models/global_weights.pth')
    print("\n[SERVER] Global model weights saved to models/global_weights.pth")
    
    # Print evaluation results summary
    print("\n[SERVER] Federated Learning Complete!")
    print("Summary of evaluation results:")
    for result in strategy.evaluation_results:
        print(f"  Round {result['round']}: Loss={result['metrics']['test_loss']:.4f}, "
              f"Dice={result['metrics']['test_dice']:.4f}, "
              f"Acc={result['metrics']['test_accuracy']:.4f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Flower Server for Federated Learning")
    
    parser.add_argument('--server_address', type=str, default='127.0.0.1:8080',
                       help='Server address (default: 127.0.0.1:8080)')
    parser.add_argument('--num_rounds', type=int, default=5,
                       help='Number of federated learning rounds (default: 5)')
    parser.add_argument('--min_fit_clients', type=int, default=2,
                       help='Minimum fit clients (default: 2)')
    parser.add_argument('--min_evaluate_clients', type=int, default=2,
                       help='Minimum evaluate clients (default: 2)')
    parser.add_argument('--min_available_clients', type=int, default=2,
                       help='Minimum available clients (default: 2)')
    parser.add_argument('--use_ssl', action='store_true',
                       help='Use SSL certificates for secure communication')
    
    args = parser.parse_args()
    main(args)