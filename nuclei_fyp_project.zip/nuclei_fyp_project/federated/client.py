"""
Federated Learning Client using Flower Framework.

Client-side implementation:
1. Receives global model weights from server
2. Trains on local data (never leaves the client)
3. Sends back model updates (weights only)
4. Evaluates on local test set

PRIVACY GUARANTEE:
- Raw training data stays on client device
- Only model weights are transmitted to server
- No access logs or data patterns are exposed
"""

import os
import sys
from pathlib import Path
from typing import Tuple, Dict, List
import argparse

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

# Add parent directory to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from models.model import create_model
from federated.federated_utils import (
    model_to_weights,
    weights_to_model,
    CombinedLoss,
    SegmentationMetrics,
    ClassificationMetrics
)
from utils.mock_data_generator import generate_mock_dataset

import flwr as fl
from flwr.common import NDArray


# ==================== Client Class ====================

class FederatedLearningClient(fl.client.NumPyClient):
    """
    Federated Learning Client for Flower Framework.
    
    Implements local training and evaluation on private data.
    """
    
    def __init__(
        self,
        client_id: int,
        model: nn.Module,
        train_loader: DataLoader,
        test_loader: DataLoader,
        device: torch.device,
        num_epochs: int = 3,
        learning_rate: float = 0.001
    ):
        """
        Initialize federated learning client.
        
        Args:
            client_id: Unique client identifier
            model: Neural network model
            train_loader: DataLoader for training
            test_loader: DataLoader for testing
            device: Device to train on (cpu/cuda)
            num_epochs: Number of local epochs per round
            learning_rate: Learning rate for optimizer
        """
        self.client_id = client_id
        self.model = model.to(device)
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.device = device
        self.num_epochs = num_epochs
        self.learning_rate = learning_rate
        
        # Loss and optimizer
        self.criterion = CombinedLoss(lambda_seg=1.0, lambda_cls=0.5)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        
        print(f"[CLIENT {client_id}] Initialized with {len(train_loader)} training batches")
    
    def train_local(self) -> Dict[str, float]:
        """
        Train model on local data.
        
        PRIVACY NOTE:
        - This runs entirely on the client device
        - No training data leaves the client
        - Only model weights are sent to server
        
        Returns:
            Dictionary with training metrics
        """
        self.model.train()
        total_loss = 0.0
        total_dice = 0.0
        total_acc = 0.0
        num_batches = 0
        
        for epoch in range(self.num_epochs):
            epoch_loss = 0.0
            
            for batch in self.train_loader:
                # Get data
                images = batch[0].to(self.device)
                masks = batch[1].to(self.device)
                labels = batch[2].to(self.device)
                
                # Forward pass
                seg_output, cls_output = self.model(images)
                
                # Compute loss
                loss, _ = self.criterion(seg_output, masks, cls_output, labels)
                
                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
                
                # Compute metrics
                seg_probs = torch.sigmoid(seg_output).detach().cpu().numpy()
                seg_target = masks.detach().cpu().numpy()
                dice = np.mean([
                    SegmentationMetrics.dice_coefficient(p, t)
                    for p, t in zip(seg_probs, seg_target)
                ])
                
                cls_pred = cls_output.argmax(dim=1).detach().cpu().numpy()
                cls_target = labels.detach().cpu().numpy()
                acc = ClassificationMetrics.accuracy(cls_pred, cls_target)
                
                total_loss += loss.item()
                total_dice += dice
                total_acc += acc
                num_batches += 1
            
            print(f"[CLIENT {self.client_id}] Epoch {epoch+1}/{self.num_epochs} "
                  f"Loss: {epoch_loss/len(self.train_loader):.4f}")
        
        metrics = {
            'train_loss': total_loss / num_batches if num_batches > 0 else 0.0,
            'train_dice': total_dice / num_batches if num_batches > 0 else 0.0,
            'train_accuracy': total_acc / num_batches if num_batches > 0 else 0.0,
            'num_samples': len(self.train_loader.dataset)
        }
        
        return metrics
    
    def evaluate_local(self) -> Tuple[float, Dict[str, float]]:
        """
        Evaluate model on local test data.
        
        Args:
            
        Returns:
            (loss, metrics_dict) tuple
        """
        self.model.eval()
        total_loss = 0.0
        dice_scores = []
        accuracies = []
        
        with torch.no_grad():
            for batch in self.test_loader:
                images = batch[0].to(self.device)
                masks = batch[1].to(self.device)
                labels = batch[2].to(self.device)
                
                seg_output, cls_output = self.model(images)
                
                loss, _ = self.criterion(seg_output, masks, cls_output, labels)
                total_loss += loss.item()
                
                seg_probs = torch.sigmoid(seg_output).cpu().numpy()
                seg_target = masks.cpu().numpy()
                for p, t in zip(seg_probs, seg_target):
                    dice_scores.append(
                        SegmentationMetrics.dice_coefficient(p, t)
                    )
                
                cls_pred = cls_output.argmax(dim=1).cpu().numpy()
                cls_target = labels.cpu().numpy()
                accuracies.append(
                    ClassificationMetrics.accuracy(cls_pred, cls_target)
                )
        
        avg_loss = total_loss / len(self.test_loader) if len(self.test_loader) > 0 else 0.0
        
        metrics = {
            'test_loss': avg_loss,
            'test_dice': float(np.mean(dice_scores)) if dice_scores else 0.0,
            'test_accuracy': float(np.mean(accuracies)) if accuracies else 0.0
        }
        
        return avg_loss, metrics
    
    def get_parameters(self, config=None) -> List[NDArray]:
        """
        Get model parameters as numpy arrays for transmission to server.
        
        PRIVACY NOTE:
        Only weights are returned, no training data or gradients.
        """
        weights = model_to_weights(self.model)
        return [weights[name] for name in sorted(weights.keys())]
    
    def fit(self, parameters: List[NDArray], config: Dict):
        """
        Fit model on local data.
        
        Receives global model from server, trains locally, sends back updates.
        """
        print(f"\n[CLIENT {self.client_id}] Starting local training...")
        
        weights_dict = {
            name: param
            for name, param in zip(sorted(self.model.state_dict().keys()), parameters)
        }
        self.model = weights_to_model(self.model, weights_dict)
        
        train_metrics = self.train_local()
        
        updated_weights = self.get_parameters(config)
        return updated_weights, len(self.train_loader.dataset), train_metrics
    
    def evaluate(self, parameters: List[NDArray], config: Dict):
        """
        Evaluate model on local test data.
        """
        print(f"[CLIENT {self.client_id}] Evaluating on local test data...")
        
        weights_dict = {
            name: param
            for name, param in zip(sorted(self.model.state_dict().keys()), parameters)
        }
        self.model = weights_to_model(self.model, weights_dict)
        
        loss, metrics = self.evaluate_local()
        return loss, len(self.test_loader.dataset), metrics


# ==================== Client Setup ====================

def create_client_datasets(
    client_id: int,
    num_samples_per_class: int = 5,
    test_ratio: float = 0.2
) -> Tuple[DataLoader, DataLoader]:
    """
    Generate datasets for a specific client.
    
    Each client gets a different random subset of data.
    """
    np.random.seed(42 + client_id)
    torch.manual_seed(42 + client_id)
    
    images, masks, labels = generate_mock_dataset(
        output_dir=None,
        num_samples_per_class=num_samples_per_class
    )
    
    images = torch.tensor(images).permute(0, 3, 1, 2).float() / 255.0
    masks = torch.tensor(masks).unsqueeze(1).float() / 255.0
    labels = torch.tensor(labels).long()
    
    num_samples = len(images)
    split = int(num_samples * (1 - test_ratio))
    idx = torch.randperm(num_samples)
    
    train_ds = TensorDataset(images[idx[:split]], masks[idx[:split]], labels[idx[:split]])
    test_ds = TensorDataset(images[idx[split:]], masks[idx[split:]], labels[idx[split:]])
    
    return (
        DataLoader(train_ds, batch_size=4, shuffle=True),
        DataLoader(test_ds, batch_size=4)
    )


# ==================== Main Function ====================

def main(args):
    """Run federated learning client."""
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[CLIENT {args.client_id}] Using device: {device}")
    
    model = create_model()
    
    train_loader, test_loader = create_client_datasets(args.client_id)
    
    client = FederatedLearningClient(
        client_id=args.client_id,
        model=model,
        train_loader=train_loader,
        test_loader=test_loader,
        device=device,
        num_epochs=args.num_epochs,
        learning_rate=args.learning_rate
    )
    
    fl.client.start_numpy_client(
        server_address=args.server_address,
        client=client
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--client_id", type=int, default=0)
    parser.add_argument("--server_address", type=str, default="127.0.0.1:8080")
    parser.add_argument("--num_epochs", type=int, default=3)
    parser.add_argument("--learning_rate", type=float, default=0.001)
    main(parser.parse_args())