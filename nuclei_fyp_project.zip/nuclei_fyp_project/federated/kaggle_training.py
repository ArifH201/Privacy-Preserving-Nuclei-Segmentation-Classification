"""
Kaggle-optimized federated learning training script
Run this on Kaggle instead of run_system.py (which uses subprocess)

Usage in Kaggle notebook:
    from federated.kaggle_training import train_federated_kaggle
    model = train_federated_kaggle(num_rounds=3, num_clients=2)
"""

import os
import sys
import torch
import numpy as np
import gc
from pathlib import Path
from collections import OrderedDict

# For Kaggle environment setup
try:
    project_root = Path('/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')
    sys.path.insert(0, str(project_root))
except Exception:
    pass

from models.model import MultiTaskUNet
from utils.pannuke_dataset import PanNukeDataset
from federated.federated_utils import (
    ClassificationMetrics, SegmentationMetrics,
    average_weights
)


class KaggleTrainer:
    """Federated Learning trainer optimized for Kaggle"""

    def __init__(self, device=None):
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.global_model = None
        self.training_history = []

    def setup_model(self):
        """Initialize global model"""
        self.global_model = MultiTaskUNet(
            in_channels=3,
            base_channels=64,
            num_classes=19
        ).to(self.device)

        total_params = sum(p.numel() for p in self.global_model.parameters())
        print(f"✓ Model initialized: {total_params:,} parameters")

    def load_client_data(self, num_clients=3):
        """Load PanNuke dataset and split into federated clients"""
        print(f"\n[STEP 1] Loading PanNuke dataset...")

        dataset = PanNukeDataset(
            images_path="dataset/images.npy",
            masks_path="dataset/masks.npy",
            types_path="dataset/types.npy"
        )

        total_size = len(dataset)
        split_size = total_size // num_clients
        
        # Define split lengths
        lengths = [split_size] * (num_clients - 1)
        lengths.append(total_size - sum(lengths))

        clients = torch.utils.data.random_split(dataset, lengths)
        client_data = []

        for cid, client_ds in enumerate(clients):
            images, masks, labels = [], [], []

            for img, mask, label in client_ds:
                # Convert back to HWC for the normalizer later
                images.append(img.permute(1, 2, 0).numpy() * 255)
                masks.append(mask.numpy())
                labels.append(label.numpy())

            client_data.append({
                "id": cid,
                "images": np.array(images),
                "seg_masks": np.array(masks),
                "cls_labels": np.array(labels)
            })

        print("✓ PanNuke dataset loaded and split")
        return client_data

    def train_client(self, client_id, client_data, global_weights, normalizer, 
                     num_epochs=2, batch_size=8, learning_rate=0.001):
        """Train model on single client's local data and return updated weights + metrics"""
        
        # Sync local model with global weights
        for param, weight in zip(self.global_model.parameters(), global_weights):
            param.data = torch.from_numpy(weight).to(self.device)

        # Preprocessing & Normalization
        images = np.stack([normalizer(img) for img in client_data['images']])
        images = torch.tensor(images).permute(0, 3, 1, 2).float() / 255.0
        masks = torch.tensor(client_data['seg_masks']).long()
        labels = torch.tensor(client_data['cls_labels']).long()

        dataset = torch.utils.data.TensorDataset(images, masks, labels)
        loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)

        seg_loss_fn = torch.nn.CrossEntropyLoss()
        cls_loss_fn = torch.nn.CrossEntropyLoss()
        optimizer = torch.optim.Adam(self.global_model.parameters(), lr=learning_rate)

        # Local Training Loop
        self.global_model.train()
        for epoch in range(num_epochs):
            epoch_loss = 0
            for batch_imgs, batch_masks, batch_labels in loader:
                batch_imgs = batch_imgs.to(self.device)
                batch_masks = batch_masks.to(self.device)
                batch_labels = batch_labels.to(self.device)

                optimizer.zero_grad()
                seg_out, cls_out = self.global_model(batch_imgs)
                
                loss = seg_loss_fn(seg_out, batch_masks) + cls_loss_fn(cls_out, batch_labels)
                loss.backward()
                optimizer.step()
                
                epoch_loss += loss.item()
            
            print(f"      Epoch {epoch+1}/{num_epochs}: Loss = {epoch_loss/len(loader):.4f}")

        # Local Evaluation
        self.global_model.eval()
        all_seg_probs = []
        all_cls_preds = []
        eval_loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=False)

        with torch.no_grad():
            for batch_imgs, _, _ in eval_loader:
                batch_imgs = batch_imgs.to(self.device)
                seg_out, cls_out = self.global_model(batch_imgs)
                all_seg_probs.append(torch.argmax(seg_out, dim=1).cpu().numpy())
                all_cls_preds.append(torch.argmax(cls_out, dim=1).cpu().numpy())

        seg_probs = np.concatenate(all_seg_probs, axis=0)
        cls_preds = np.concatenate(all_cls_preds, axis=0)

        updated_weights = [param.data.cpu().numpy() for param in self.global_model.parameters()]
        
        # Calculate Metrics
        dice = SegmentationMetrics.dice_coefficient(
            seg_probs, 
            client_data['seg_masks']
        )
        acc = ClassificationMetrics.accuracy(cls_preds, client_data['cls_labels'])

        return updated_weights, {'client_id': client_id, 'dice': dice, 'accuracy': acc}

    def train(self, num_rounds=3, num_clients=2, num_epochs=2, batch_size=8, learning_rate=0.001):
        """Main federated training loop"""
        print("=" * 80)
        print("FEDERATED LEARNING TRAINING (KAGGLE OPTIMIZED)")
        print("=" * 80)

        self.setup_model()
        client_data = self.load_client_data(num_clients)
        
        # Note: Ensure setup_normalizer is defined in your environment/utils
        normalizer = self.setup_normalizer(client_data)

        # Initial weights
        global_weights = [p.cpu().detach().numpy() for p in self.global_model.parameters()]

        for rnd in range(1, num_rounds + 1):
            print(f"\n{'='*60}\nROUND {rnd}/{num_rounds}\n{'='*60}")

            client_updates = []
            round_metrics = []

            for cid in range(num_clients):
                print(f"\n  Client {cid + 1}/{num_clients}")
                weights, metrics = self.train_client(
                    cid, client_data[cid], global_weights,
                    normalizer, num_epochs, batch_size, learning_rate
                )
                client_updates.append(weights)
                round_metrics.append(metrics)

                # Memory management for Kaggle
                gc.collect()
                torch.cuda.empty_cache()

            # Simple Federated Averaging
            global_weights = [
                np.mean([client[i] for client in client_updates], axis=0)
                for i in range(len(global_weights))
            ]

            avg_dice = np.mean([m['dice'] for m in round_metrics])
            avg_acc = np.mean([m['accuracy'] for m in round_metrics])

            print(f"\nRound {rnd} Summary:")
            print(f"  Average Dice: {avg_dice:.4f}")
            print(f"  Average Accuracy: {avg_acc:.4f}")

        # Finalize global model with trained weights
        for param, weight in zip(self.global_model.parameters(), global_weights):
            param.data = torch.from_numpy(weight).to(self.device)

        print("\nTRAINING COMPLETE")
        return self.global_model

    def setup_normalizer(self, client_data):
        """Placeholder for your normalizer logic if not defined elsewhere"""
        # Replace with your actual normalization logic (e.g., Stain Normalization)
        return lambda x: x


def train_federated_kaggle(num_rounds=3, num_clients=2, num_epochs=2,
                           batch_size=8, learning_rate=0.001):
    """Simplified function for one-line training on Kaggle"""
    trainer = KaggleTrainer()
    return trainer.train(
        num_rounds, num_clients, num_epochs, batch_size, learning_rate
    )


if __name__ == "__main__":
    print("Starting Kaggle Training Demo...")
    model = train_federated_kaggle(num_rounds=2, num_clients=2, num_epochs=1)
    print("\n✓ Training demo complete!")