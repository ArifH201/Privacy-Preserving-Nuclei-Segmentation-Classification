"""
Multi-Task U-Net for Privacy-Preserving Nuclei Segmentation and Classification.

This model implements a shared encoder-decoder architecture with two task-specific heads:
- Head A: Semantic Segmentation (produces binary masks for nuclei)
- Head B: Classification (4-class classification: Tumor, Inflammatory, Stroma, Necrosis)

Architecture:
- Shared Encoder: Downsampling path with residual blocks
- Shared Decoder: Upsampling path with skip connections
- Segmentation Head: Binary cross-entropy loss on mask output
- Classification Head: Cross-entropy loss on 4-class labels

Privacy Note: Only model weights are shared during federated learning, never training data.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple


class ConvBlock(nn.Module):
    """
    Convolutional block with batch normalization and ReLU activation.
    Used in the encoder and decoder paths.
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3):
        super(ConvBlock, self).__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=padding)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class ResidualBlock(nn.Module):
    """
    Residual block for improved gradient flow during training.
    Implements skip connection: output = conv(input) + input
    """
    def __init__(self, channels: int):
        super(ResidualBlock, self).__init__()
        self.conv1 = ConvBlock(channels, channels)
        self.conv2 = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(channels)
        )

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.conv2(out)
        out = out + residual
        out = F.relu(out)
        return out


class Encoder(nn.Module):
    """
    Encoder path of U-Net. Progressively downsamples the input while
    increasing channel depth. Returns features at multiple scales for skip connections.
    """
    def __init__(self, in_channels: int = 3, base_channels: int = 64):
        super(Encoder, self).__init__()
        self.base_channels = base_channels

        # Level 0: Input convolution
        self.conv0 = nn.Sequential(
            ConvBlock(in_channels, base_channels),
            ConvBlock(base_channels, base_channels)
        )

        # Level 1: 64 -> 128 channels
        self.down1 = nn.MaxPool2d(2, 2)
        self.conv1 = nn.Sequential(
            ConvBlock(base_channels, base_channels * 2),
            ResidualBlock(base_channels * 2)
        )

        # Level 2: 128 -> 256 channels
        self.down2 = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Sequential(
            ConvBlock(base_channels * 2, base_channels * 4),
            ResidualBlock(base_channels * 4)
        )

        # Level 3: 256 -> 512 channels (bottleneck)
        self.down3 = nn.MaxPool2d(2, 2)
        self.conv3 = nn.Sequential(
            ConvBlock(base_channels * 4, base_channels * 8),
            ResidualBlock(base_channels * 8)
        )

    def forward(self, x):
        """
        Forward pass through encoder.
        Returns intermediate features for skip connections.
        """
        c0 = self.conv0(x)
        
        x = self.down1(c0)
        c1 = self.conv1(x)
        
        x = self.down2(c1)
        c2 = self.conv2(x)
        
        x = self.down3(c2)
        c3 = self.conv3(x)
        
        return c0, c1, c2, c3


class Decoder(nn.Module):
    """
    Decoder path of U-Net. Progressively upsamples features while
    combining them with skip connections from the encoder.
    """
    def __init__(self, base_channels: int = 64):
        super(Decoder, self).__init__()
        self.base_channels = base_channels

        # Upsample Level 3 -> 2
        self.up3 = nn.ConvTranspose2d(base_channels * 8, base_channels * 4, kernel_size=2, stride=2)
        self.conv_up3 = nn.Sequential(
            ConvBlock(base_channels * 8, base_channels * 4),
            ResidualBlock(base_channels * 4)
        )

        # Upsample Level 2 -> 1
        self.up2 = nn.ConvTranspose2d(base_channels * 4, base_channels * 2, kernel_size=2, stride=2)
        self.conv_up2 = nn.Sequential(
            ConvBlock(base_channels * 4, base_channels * 2),
            ResidualBlock(base_channels * 2)
        )

        # Upsample Level 1 -> 0
        self.up1 = nn.ConvTranspose2d(base_channels * 2, base_channels, kernel_size=2, stride=2)
        self.conv_up1 = nn.Sequential(
            ConvBlock(base_channels * 2, base_channels),
            ConvBlock(base_channels, base_channels)
        )

    def forward(self, c0, c1, c2, c3):
        """
        Forward pass through decoder.
        Combines upsampled features with skip connections from encoder.
        """
        x = self.up3(c3)
        x = torch.cat([x, c2], dim=1)
        x = self.conv_up3(x)

        x = self.up2(x)
        x = torch.cat([x, c1], dim=1)
        x = self.conv_up2(x)

        x = self.up1(x)
        x = torch.cat([x, c0], dim=1)
        x = self.conv_up1(x)

        return x


class MultiTaskUNet(nn.Module):
    """
    Multi-Task U-Net for simultaneous nuclei segmentation and classification.
    
    This architecture shares a common encoder-decoder backbone and uses two
    task-specific heads:
    1. Segmentation Head: Binary mask prediction for nuclei regions
    2. Classification Head: 4-class classification of tissue types
    
    Privacy Consideration:
    - Only model parameters are shared during federated learning
    - Training data never leaves local clients
    - Gradient aggregation happens server-side
    """
    def __init__(self, in_channels: int = 3, base_channels: int = 64, num_classes: int = 19):
        """
        Initialize Multi-Task U-Net.
        
        Args:
            in_channels: Number of input channels (3 for RGB H&E images)
            base_channels: Base number of channels for feature maps
            num_classes: Number of classification classes (default: 4)
        """
        super(MultiTaskUNet, self).__init__()
        self.in_channels = in_channels
        self.base_channels = base_channels
        self.num_classes = num_classes

        # Shared backbone
        self.encoder = Encoder(in_channels, base_channels)
        self.decoder = Decoder(base_channels)

        # Segmentation head: Multi-class mask output (6 nucleus classes from PanNuke)
        self.seg_head = nn.Conv2d(base_channels, 6, kernel_size=1)

        # Classification head: Global average pooling + FC layers
        self.class_head = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),  # Global average pooling
            nn.Flatten(),
            nn.Linear(base_channels * 8, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes)  # Logits for num_classes
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through the multi-task U-Net.
        
        Args:
            x: Input tensor of shape (batch_size, 3, height, width)
            
        Returns:
            seg_out: Segmentation logits of shape (batch_size, 6, height, width)
            cls_out: Classification logits of shape (batch_size, num_classes)
        """
        # Encode
        c0, c1, c2, c3 = self.encoder(x)

        # Decode
        shared_features = self.decoder(c0, c1, c2, c3)

        # Task-specific heads
        seg_out = self.seg_head(shared_features)
        cls_out = self.class_head(c3)

        return seg_out, cls_out

    def get_parameter_count(self) -> int:
        """Returns total number of trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def create_model(in_channels: int = 3, base_channels: int = 64, num_classes: int = 19) -> MultiTaskUNet:
    """
    Factory function to create a MultiTaskUNet model.
    
    Args:
        in_channels: Input channels (default: 3 for RGB)
        base_channels: Base feature channels (default: 64)
        num_classes: Number of classification classes (default: 4)
        
    Returns:
        Initialized MultiTaskUNet model
    """
    model = MultiTaskUNet(in_channels, base_channels, num_classes)
    return model


if __name__ == "__main__":
    # Test the model
    model = create_model()
    print(f"Model created with {model.get_parameter_count():,} parameters")
    
    # Create dummy input
    dummy_input = torch.randn(2, 3, 256, 256)
    
    # Forward pass
    seg_output, cls_output = model(dummy_input)
    
    print(f"Input shape: {dummy_input.shape}")
    print(f"Segmentation output shape: {seg_output.shape}")
    print(f"Classification output shape: {cls_output.shape}")