"""Test loss functions"""

import sys
from pathlib import Path
import torch

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from federated.federated_utils import DiceLoss

print("=" * 60)
print("LOSS FUNCTIONS TEST")
print("=" * 60)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Test Dice Loss
print("\n[1] Testing Dice Loss...")
dice_loss = DiceLoss()

# Perfect prediction (loss should be ~0)
pred_perfect = torch.ones(2, 1, 32, 32, device=device)
target_perfect = torch.ones(2, 1, 32, 32, device=device)
loss_perfect = dice_loss(pred_perfect, target_perfect)
print(f"  Perfect prediction loss: {loss_perfect:.6f}")
assert loss_perfect < 0.01, "Perfect prediction should have ~0 loss"
print("  ✓ Perfect case OK")

# Bad prediction (loss should be ~1)
pred_bad = torch.zeros(2, 1, 32, 32, device=device)
target_bad = torch.ones(2, 1, 32, 32, device=device)
loss_bad = dice_loss(pred_bad, target_bad)
print(f"  Bad prediction loss: {loss_bad:.6f}")
assert loss_bad > 0.9, "Bad prediction should have ~1 loss"
print("  ✓ Bad case OK")

# Partial prediction (loss between 0 and 1)
pred_partial = torch.rand(2, 1, 32, 32, device=device)
target_partial = torch.rand(2, 1, 32, 32, device=device) > 0.5
loss_partial = dice_loss(pred_partial.float(), target_partial.float())
print(f"  Partial prediction loss: {loss_partial:.6f}")
assert 0 <= loss_partial <= 1, "Loss should be between 0 and 1"
print("  ✓ Partial case OK")

print("✓ Dice Loss tests passed")

# Test Classification Loss
print("\n[2] Testing Classification Loss...")
cls_loss = torch.nn.CrossEntropyLoss()

# Perfect prediction
pred_cls_perfect = torch.zeros(4, 4)
pred_cls_perfect[0, 0] = 100  # High confidence in correct class
pred_cls_perfect[1, 1] = 100
pred_cls_perfect[2, 2] = 100
pred_cls_perfect[3, 3] = 100
target_cls_perfect = torch.tensor([0, 1, 2, 3])
loss_cls_perfect = cls_loss(pred_cls_perfect, target_cls_perfect)
print(f"  Perfect prediction loss: {loss_cls_perfect:.6f}")
assert loss_cls_perfect < 0.01, "Perfect prediction should have ~0 loss"
print("  ✓ Perfect case OK")

# Partial prediction
pred_cls_partial = torch.randn(4, 4)
target_cls_partial = torch.tensor([0, 1, 2, 3])
loss_cls_partial = cls_loss(pred_cls_partial, target_cls_partial)
print(f"  Partial prediction loss: {loss_cls_partial:.6f}")
assert loss_cls_partial > 0, "Loss should be positive"
print("  ✓ Partial case OK")

print("✓ Classification Loss tests passed")

print("\n" + "=" * 60)
print("✓ LOSS FUNCTIONS TEST PASSED")
print("=" * 60)
