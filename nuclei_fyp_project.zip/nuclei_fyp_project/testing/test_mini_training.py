"""Mini federated training test (1 round, 1 client, 1 epoch)"""

import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from federated.kaggle_training import KaggleTrainer

print("=" * 60)
print("MINI FEDERATED TRAINING TEST")
print("=" * 60)
print("\nConfiguration: 1 round, 1 client, 1 epoch (2-3 min)")

try:
    trainer = KaggleTrainer()
    model = trainer.train(
        num_rounds=1,
        num_clients=1,
        num_epochs=1,
        batch_size=16,
        learning_rate=0.001
    )
    
    print("\n" + "=" * 60)
    print("✓ MINI TRAINING TEST PASSED")
    print("=" * 60)
    print("\nReady for full training on Kaggle!")
    
except Exception as e:
    print(f"\n✗ Training failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
