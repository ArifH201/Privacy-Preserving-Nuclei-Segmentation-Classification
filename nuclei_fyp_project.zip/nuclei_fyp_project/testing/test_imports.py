"""Test that all modules import correctly"""

import sys
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("Testing imports...")

try:
    print("  • Importing models...", end=" ")
    from models.model import MultiTaskUNet
    print("✓")
    
    print("  • Importing utils...", end=" ")
    from utils.normalization import ReinhardNormalizer
    from utils.image_processing import HistologyDataset
    from utils.mock_data_generator import SyntheticHEImageGenerator
    print("✓")
    
    print("  • Importing federated utils...", end=" ")
    from federated.federated_utils import DiceLoss, average_weights
    print("✓")
    
    print("  • Importing torch...", end=" ")
    import torch
    print(f"✓ (v{torch.__version__})")
    
    print("  • Importing flwr...", end=" ")
    import flwr
    print("✓")
    
    print("\n✓ All imports successful!")
    
except Exception as e:
    print(f"\n✗ Import failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
