# Testing Steps - Complete Guide

## Quick Start

```powershell
# After installing dependencies:
# pip install -r requirements.txt

# Then run:
python run_all_tests.py
```

Expected: All 6 tests pass in ~5-10 minutes ✓

---

## Testing Stages

### **Stage 1: Pre-Flight Check (5 minutes)**

**Why**: Verify environment before spending time on training

**Run**:
```powershell
# 1. Validate project structure
python validate_project.py

# 2. Test imports
python test_imports.py
```

**If both pass** → Continue to Stage 2

---

### **Stage 2: Unit Tests (3-5 minutes)**

**Why**: Verify individual components work

**Run**:
```powershell
python test_model.py           # Model architecture
python test_data_generation.py # Data generation
python test_normalization.py   # Stain normalization
python test_losses.py          # Loss functions
```

**Expected**: All pass ✓

---

### **Stage 3: Mini Training (2-3 minutes)**

**Why**: Full end-to-end test before real training

**Run**:
```powershell
python test_mini_training.py
```

**Configuration**: 1 round, 1 client, 1 epoch

**Expected Output**:
```
============================================================
MINI FEDERATED TRAINING TEST
============================================================

[STEP 1] Generating synthetic H&E data for 1 clients...
✓ Generated 30 total images

[STEP 2] Setting up stain normalization...
✓ Stain normalizer fitted on reference images

[STEP 3] Starting federated training for 1 rounds...

  Client 1/1 Local Training:
    Training for 1 epochs...
      Epoch 1/1: Loss = 0.6123
    Evaluating...
    ✓ Dice Score: 0.7234
    ✓ Accuracy: 0.8500

  Server Aggregation:
    ✓ Weights aggregated from 1 clients

============================================================
✓ MINI FEDERATED TRAINING TEST PASSED
============================================================
```

---

### **Stage 4: Kaggle Testing**

**Why**: Verify environment before uploading

#### On Kaggle Notebook:

**Cell 1: Environment**
```python
import torch
print(f"PyTorch: {torch.__version__}")
print(f"GPU: {torch.cuda.is_available()}")
```

**Cell 2: Imports**
```python
import sys
sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')

from models.model import MultiTaskUNet
from utils.mock_data_generator import SyntheticHEImageGenerator
from federated.kaggle_training import train_federated_kaggle

print("✓ All imports successful")
```

**Cell 3: Model Test**
```python
import torch
from models.model import MultiTaskUNet

model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device).eval()

x = torch.randn(1, 3, 256, 256).to(device)
with torch.no_grad():
    seg, cls = model(x)

print(f"✓ Model works: seg={seg.shape}, cls={cls.shape}")
```

**Cell 4: Mini Training**
```python
from federated.kaggle_training import train_federated_kaggle

model = train_federated_kaggle(
    num_rounds=1,
    num_clients=1,
    num_epochs=1,
    batch_size=16
)
print("✓ Mini training passed!")
```

**Cell 5: Full Training**
```python
model = train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8
)
print("✓ Full training complete!")
```

---

## Testing Checklist

### Before Starting Any Training

- [ ] Python 3.9+ installed
- [ ] `pip install -r requirements.txt` completed
- [ ] `python validate_project.py` passes
- [ ] `python test_imports.py` passes
- [ ] All 19 project files present

### Unit Tests (All Should Pass)

- [ ] `python test_model.py` ✓
- [ ] `python test_data_generation.py` ✓
- [ ] `python test_normalization.py` ✓
- [ ] `python test_losses.py` ✓

### Integration Test

- [ ] `python test_mini_training.py` passes ✓

### Ready for Kaggle

- [ ] Mini training completed successfully
- [ ] No errors in any test
- [ ] GPU available (if using Kaggle GPU)
- [ ] Dataset uploaded to Kaggle (if needed)

---

## Test Scenarios

### Scenario A: Local Machine Before Kaggle

```powershell
# 1. Install
pip install -r requirements.txt

# 2. Validate
python validate_project.py

# 3. Test imports
python test_imports.py

# 4. Full test suite
python run_all_tests.py

# If all pass → Ready for Kaggle!
```

### Scenario B: Fresh Kaggle Notebook

```python
# Cell 1: Install
!pip install -q torch flwr scikit-image scikit-learn albumentations

# Cell 2: Setup
import sys
sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')

# Cell 3: Test
from federated.kaggle_training import train_federated_kaggle
model = train_federated_kaggle(num_rounds=1, num_clients=1)

# If passes → Run full training!
```

### Scenario C: Verify Trained Model

```python
import torch
from models.model import MultiTaskUNet

# Load model
model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
model.load_state_dict(torch.load('models/federated_model.pth'))
model.eval()

# Test inference
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

x = torch.randn(1, 3, 256, 256).to(device)
with torch.no_grad():
    seg, cls = model(x)

print("✓ Model inference works!")
```

---

## Performance Benchmarks

### Expected Times

| Test | Time | Notes |
|------|------|-------|
| `test_imports.py` | <1 sec | Just imports |
| `test_model.py` | ~5 sec | Forward pass only |
| `test_data_generation.py` | ~5 sec | Generate 10 images |
| `test_normalization.py` | ~1 sec | Normalize batch |
| `test_losses.py` | ~1 sec | Compute losses |
| `test_mini_training.py` | 2-3 min | 1 round training |
| **Total** | **~3-4 min** | Full suite (CPU) |

### GPU Acceleration

| Component | CPU | GPU | Speedup |
|-----------|-----|-----|---------|
| Model Forward | 30-50ms | 10-15ms | 3-5x |
| Mini Training | 2-3 min | 30-60 sec | 3-6x |
| Full Training | 30-45 min | 10-20 min | 2-4x |

---

## Common Issues & Solutions

### Issue 1: "ModuleNotFoundError: No module named 'torch'"

**Solution**:
```powershell
pip install -r requirements.txt
```

### Issue 2: "GPU not found" on Kaggle

**Solution**:
1. Check Settings → Accelerator = GPU
2. Restart kernel
3. Verify with:
   ```python
   import torch
   print(torch.cuda.is_available())  # Should be True
   ```

### Issue 3: "CUDA out of memory"

**Solution**: Reduce batch size
```python
train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    batch_size=4  # Reduced from 8
)
```

### Issue 4: Test passes locally but fails on Kaggle

**Solution**: Usually import path issue
```python
import sys
sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')
# Use correct path for your uploaded dataset
```

### Issue 5: "Timeout after 9 hours" on Kaggle

**Solution**: Reduce training scope
```python
train_federated_kaggle(
    num_rounds=2,      # Reduced from 5
    num_clients=1,     # Reduced from 3
    num_epochs=1,      # Reduced from 3
    batch_size=16      # Increased for speed
)
```

---

## Success Criteria

### All Tests Pass ✓

```
✓ test_imports.py          PASSED
✓ test_model.py            PASSED
✓ test_data_generation.py  PASSED
✓ test_normalization.py    PASSED
✓ test_losses.py           PASSED
✓ test_mini_training.py    PASSED
```

### Expected Metrics

After mini training:
- Segmentation Dice: 0.50-0.75
- Classification Accuracy: 0.60-0.90

After full training (3 rounds):
- Segmentation Dice: 0.70-0.85
- Classification Accuracy: 0.75-0.95

---

## Testing Documentation Files

| File | Purpose |
|------|---------|
| `TESTING_GUIDE.md` | Detailed testing procedures |
| `TESTING_QUICK_REFERENCE.md` | Quick lookup table |
| `KAGGLE_TRAINING_GUIDE.md` | Complete Kaggle setup |
| `KAGGLE_FULL_WORKFLOW.md` | Step-by-step Kaggle notebook |

---

## Next Steps After Testing

### If All Tests Pass ✓

1. Upload project to Kaggle (if not done)
2. Create new Kaggle notebook
3. Follow `KAGGLE_FULL_WORKFLOW.md`
4. Run full training
5. Download results

### If Any Test Fails ✗

1. Read error message carefully
2. Check "Common Issues & Solutions"
3. Verify dependencies: `pip install -r requirements.txt`
4. Try individual test in isolation
5. Check file structure: `python validate_project.py`

---

## Fast Path (Experienced Users)

```powershell
# Local validation (3 min)
pip install -r requirements.txt
python run_all_tests.py

# Upload to Kaggle

# Kaggle training (20 min)
# Copy cells from KAGGLE_FULL_WORKFLOW.md
# Run full notebook

# Download results
```

---

## Troubleshooting Wizard

```
Q: "ModuleNotFoundError"?
A: → pip install -r requirements.txt

Q: GPU not available?
A: → Check Kaggle Settings → Accelerator = GPU

Q: Out of memory?
A: → Reduce batch_size (8→4) or num_clients (2→1)

Q: Training too slow?
A: → Use GPU on Kaggle instead of local CPU

Q: Still failing?
A: → Check TESTING_GUIDE.md detailed section
```

---

## Summary

| Stage | Time | Command | Check |
|-------|------|---------|-------|
| Pre-Flight | 1 min | `python validate_project.py` | ✓ |
| Unit Tests | 2 min | `python test_imports.py` + others | ✓ |
| Mini Training | 3 min | `python test_mini_training.py` | ✓ |
| Kaggle Setup | 2 min | Cell 1-3 in Kaggle | ✓ |
| Full Training | 20 min | Cell 8 in Kaggle | ✓ |

**Total time to trained model: ~30 minutes**

