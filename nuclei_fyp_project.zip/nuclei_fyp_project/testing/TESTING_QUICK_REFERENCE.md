# Quick Testing Reference

## One-Line Test Everything

```powershell
python run_all_tests.py
```

Expected: All 6 tests pass in ~5-10 minutes

---

## Individual Tests

| Command | Purpose | Time |
|---------|---------|------|
| `python test_imports.py` | Verify all imports work | <1 min |
| `python test_model.py` | Test model forward pass | <1 min |
| `python test_data_generation.py` | Verify synthetic data | <1 min |
| `python test_normalization.py` | Test stain normalization | <1 min |
| `python test_losses.py` | Verify loss functions | <1 min |
| `python test_mini_training.py` | Mini federated training | 2-3 min |

---

## Testing Workflow

```powershell
# Step 1: Validate environment
python validate_project.py

# Step 2: Run all tests
python run_all_tests.py

# Step 3: If all pass, upload to Kaggle
# Otherwise, check error messages and fix
```

---

## Kaggle Testing Steps

### Cell 1: Environment Check
```python
import torch
import sys
sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')

print(f"PyTorch: {torch.__version__}")
print(f"GPU: {torch.cuda.is_available()}")
print(f"Device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
```

### Cell 2: Test Model
```python
from models.model import MultiTaskUNet
import torch

model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device).eval()

x = torch.randn(1, 3, 256, 256).to(device)
with torch.no_grad():
    seg, cls = model(x)

print(f"✓ Model works! Seg: {seg.shape}, Cls: {cls.shape}")
```

### Cell 3: Test Data Generation
```python
from utils.mock_data_generator import SyntheticHEImageGenerator

gen = SyntheticHEImageGenerator(256)
imgs, masks, labels = gen.generate_dataset(5)

print(f"✓ Data generated! Images: {imgs.shape}, Masks: {masks.shape}")
```

### Cell 4: Mini Training (2-3 min)
```python
from federated.kaggle_training import train_federated_kaggle

print("Testing 1-round training...")
model = train_federated_kaggle(num_rounds=1, num_clients=1, num_epochs=1, batch_size=16)
print("✓ Training works!")
```

### Cell 5: Full Training
```python
print("Starting full training...")
model = train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8
)
print("✓ Training complete!")
```

---

## Success Criteria

✅ All imports work  
✅ Model instantiates  
✅ Forward pass produces correct shapes  
✅ Data generation works  
✅ Normalization applies  
✅ Loss functions compute  
✅ Mini training completes  

→ **Ready for Kaggle!**

---

## Troubleshooting

### "ModuleNotFoundError"
```powershell
# Reinstall dependencies
pip install -r requirements.txt
```

### "CUDA out of memory"
```python
# Reduce batch size in Kaggle
batch_size = 4  # instead of 8
```

### "Timeout"
```python
# Reduce computation
num_rounds = 2
num_clients = 1
num_epochs = 1
```

### GPU not detected
```python
import torch
print(torch.cuda.is_available())  # Should be True on Kaggle GPU
```

---

## Test Results Interpretation

### Expected Times (CPU/GPU)

- Data Gen (10 imgs): 2-3 sec / <1 sec
- Model Forward: 30-50ms / 10-15ms
- 1-round training: 2-3 min / 30-60 sec

### Expected Metrics

- Dice Score: 0.4-0.8 (increases with more training)
- Accuracy: 0.4-0.9 (random labels = 25%)

### If Tests Fail

1. Check error message
2. Verify installation: `pip install -r requirements.txt`
3. Check GPU: `python -c "import torch; print(torch.cuda.is_available())"`
4. Check file structure: `python validate_project.py`
5. Try individual test in isolation

