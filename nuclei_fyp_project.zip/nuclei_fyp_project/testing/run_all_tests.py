"""Run all tests in sequence"""

import subprocess
import sys
from pathlib import Path

project_root = Path(__file__).parent
tests = [
    ("test_imports.py", "Import Test"),
    ("test_model.py", "Model Test"),
    ("test_data_generation.py", "Data Generation Test"),
    ("test_normalization.py", "Normalization Test"),
    ("test_losses.py", "Loss Functions Test"),
    ("test_mini_training.py", "Mini Training Test"),
]

print("=" * 80)
print("RUNNING FULL TEST SUITE")
print("=" * 80)

passed = 0
failed = 0

for test_file, test_name in tests:
    print(f"\n{'='*80}")
    print(f"[{passed + failed + 1}/{len(tests)}] {test_name}")
    print(f"{'='*80}\n")
    
    test_path = project_root / test_file
    
    try:
        result = subprocess.run(
            [sys.executable, str(test_path)],
            cwd=str(project_root),
            capture_output=False,
            timeout=300  # 5 minute timeout
        )
        
        if result.returncode == 0:
            print(f"\n✓ {test_name} PASSED")
            passed += 1
        else:
            print(f"\n✗ {test_name} FAILED")
            failed += 1
    
    except subprocess.TimeoutExpired:
        print(f"\n✗ {test_name} TIMEOUT")
        failed += 1
    except Exception as e:
        print(f"\n✗ {test_name} ERROR: {e}")
        failed += 1

# Summary
print(f"\n{'='*80}")
print("TEST SUMMARY")
print(f"{'='*80}")
print(f"Passed: {passed}/{len(tests)}")
print(f"Failed: {failed}/{len(tests)}")

if failed == 0:
    print("\n✓✓✓ ALL TESTS PASSED ✓✓✓")
    print("\nReady for Kaggle training!")
    sys.exit(0)
else:
    print(f"\n✗ {failed} test(s) failed. Fix issues before proceeding.")
    sys.exit(1)
