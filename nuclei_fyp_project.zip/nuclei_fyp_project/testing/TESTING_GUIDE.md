# Testing Guide for Federated Learning Project

Complete testing procedures for local validation and Kaggle deployment.

---

## Part 1: Local Testing (Before Kaggle)

### Test 1.1: Environment Validation

**Objective**: Verify all dependencies are correctly installed

**Command**:
```powershell
python validate_project.py
```

**Expected Output**:
```
✓ PyTorch installed: 2.0.1
✓ Flower installed: 1.4.0
✓ All dependencies present
✓ Project structure valid
✓ 19 files found
```

**If fails**: Run `pip install -r requirements.txt`

---

### Test 1.2: Import Testing

**Objective**: Verify all modules can be imported without errors

**Create test file** `test_imports.py`:
```python
"""Test that all modules import correctly"""

import sys
from pathlib import Path

# Add project to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("Testing imports...")

try:
    print("  • Importing models...", end=" ")
    from models.model import MultiTaskUNet
    print("✓")
    
    print("  • Importing utils...", end=" ")
    from utils.normalization import ReinhardNormalizer
    from utils.image_processing import HistologyDataset
    from utils.mock_data_generator import SyntheticHEImageGenerator
    print("✓")
    
    print("  • Importing federated utils...", end=" ")
    from federated.federated_utils import DiceLoss, average_weights
    print("✓")
    
    print("  • Importing torch...", end=" ")
    import torch
    print(f"✓ (v{torch.__version__})")
    
    print("  • Importing flwr...", end=" ")
    import flwr
    print("✓")
    
    print("\n✓ All imports successful!")
    
except Exception as e:
    print(f"\n✗ Import failed: {e}")
    sys.exit(1)
```

**Run**:
```powershell
python test_imports.py
```

**Expected Output**:
```
Testing imports...
  • Importing models... ✓
  • Importing utils... ✓
  • Importing federated utils... ✓
  • Importing torch... ✓ (v2.0.1)
  • Importing flwr... ✓

✓ All imports successful!
```

---

### Test 1.3: Model Architecture Testing

**Objective**: Verify model can be instantiated and accepts correct input shapes

**Create test file** `test_model.py`:
```python
"""Test model architecture and forward pass"""

import sys
from pathlib import Path
import torch

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from models.model import MultiTaskUNet

print("=" * 60)
print("MODEL ARCHITECTURE TEST")
print("=" * 60)

# Initialize model
print("\n[1] Instantiating model...")
model = MultiTaskUNet(
    in_channels=3,
    out_channels_seg=1,
    out_channels_cls=4,
    depth=4
)
print("✓ Model created")

# Check parameter count
total_params = sum(p.numel() for p in model.parameters())
print(f"✓ Total parameters: {total_params:,}")
print(f"✓ Model size: ~{total_params * 4 / 1e6:.1f} MB")

# Test forward pass
print("\n[2] Testing forward pass...")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)
model.eval()

# Input: batch_size=2, channels=3, height=256, width=256
test_input = torch.randn(2, 3, 256, 256).to(device)

try:
    with torch.no_grad():
        seg_out, cls_out = model(test_input)
    
    print(f"✓ Segmentation output shape: {seg_out.shape}")
    print(f"✓ Classification output shape: {cls_out.shape}")
    
    # Verify shapes
    assert seg_out.shape == (2, 1, 256, 256), f"Wrong seg output: {seg_out.shape}"
    assert cls_out.shape == (2, 4), f"Wrong cls output: {cls_out.shape}"
    print("✓ Output shapes correct")
    
except Exception as e:
    print(f"✗ Forward pass failed: {e}")
    sys.exit(1)

# Test gradient flow
print("\n[3] Testing gradient flow...")
model.train()
test_input_grad = torch.randn(2, 3, 256, 256, requires_grad=True, device=device)
seg_out, cls_out = model(test_input_grad)

try:
    loss = seg_out.mean() + cls_out.mean()
    loss.backward()
    print("✓ Backpropagation successful")
    print(f"✓ Input gradients shape: {test_input_grad.grad.shape}")
except Exception as e:
    print(f"✗ Backpropagation failed: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("✓ MODEL TEST PASSED")
print("=" * 60)
```

**Run**:
```powershell
python test_model.py
```

**Expected Output**:
```
============================================================
MODEL ARCHITECTURE TEST
============================================================

[1] Instantiating model...
✓ Model created
✓ Total parameters: 2,151,172
✓ Model size: ~8.2 MB

[2] Testing forward pass...
✓ Segmentation output shape: torch.Size([2, 1, 256, 256])
✓ Classification output shape: torch.Size([2, 4])
✓ Output shapes correct

[3] Testing gradient flow...
✓ Backpropagation successful
✓ Input gradients shape: torch.Size([2, 3, 256, 256])

============================================================
✓ MODEL TEST PASSED
============================================================
```

---

### Test 1.4: Data Generation Testing

**Objective**: Verify synthetic data generation works correctly

**Create test file** `test_data_generation.py`:
```python
"""Test synthetic H&E data generation"""

import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from utils.mock_data_generator import SyntheticHEImageGenerator

print("=" * 60)
print("DATA GENERATION TEST")
print("=" * 60)

# Initialize generator
print("\n[1] Initializing generator...")
generator = SyntheticHEImageGenerator(image_size=256)
print("✓ Generator created")

# Generate sample dataset
print("\n[2] Generating synthetic dataset...")
images, seg_masks, cls_labels = generator.generate_dataset(
    num_images=10,
    tissue_type_dist=[0.3, 0.2, 0.3, 0.2]
)

print(f"✓ Generated {len(images)} images")
print(f"  - Images shape: {images.shape}")
print(f"  - Seg masks shape: {seg_masks.shape}")
print(f"  - Cls labels shape: {cls_labels.shape}")

# Verify shapes
assert images.shape == (10, 3, 256, 256), f"Wrong images shape: {images.shape}"
assert seg_masks.shape == (10, 1, 256, 256), f"Wrong masks shape: {seg_masks.shape}"
assert cls_labels.shape == (10,), f"Wrong labels shape: {cls_labels.shape}"
print("✓ Shapes correct")

# Verify data ranges
print("\n[3] Verifying data ranges...")
print(f"  - Images range: [{images.min():.2f}, {images.max():.2f}]")
print(f"  - Masks range: [{seg_masks.min()}, {seg_masks.max()}]")
print(f"  - Labels range: [{cls_labels.min()}, {cls_labels.max()}]")

assert images.min() >= 0 and images.max() <= 255, "Images out of range"
assert seg_masks.min() >= 0 and seg_masks.max() <= 1, "Masks out of range"
assert cls_labels.min() >= 0 and cls_labels.max() < 4, "Labels out of range"
print("✓ Data ranges valid")

# Tissue type distribution
print("\n[4] Checking tissue type distribution...")
tissue_names = ['Tumor', 'Inflammatory', 'Stroma', 'Necrosis']
for tissue_id in range(4):
    count = np.sum(cls_labels == tissue_id)
    pct = 100 * count / len(cls_labels)
    print(f"  - {tissue_names[tissue_id]}: {count} ({pct:.1f}%)")
print("✓ Distribution verified")

# Visualize samples
print("\n[5] Visualizing samples...")
fig, axes = plt.subplots(2, 5, figsize=(15, 6))
for i in range(5):
    # Original image
    axes[0, i].imshow(images[i].transpose(1, 2, 0).astype(np.uint8))
    axes[0, i].set_title(f"Image {i+1}")
    axes[0, i].axis('off')
    
    # Mask
    axes[1, i].imshow(seg_masks[i, 0], cmap='gray')
    axes[1, i].set_title(f"Mask {i+1} ({tissue_names[cls_labels[i]]})")
    axes[1, i].axis('off')

plt.tight_layout()
plt.savefig('test_data_samples.png', dpi=100, bbox_inches='tight')
print("✓ Visualization saved: test_data_samples.png")

print("\n" + "=" * 60)
print("✓ DATA GENERATION TEST PASSED")
print("=" * 60)
```

**Run**:
```powershell
python test_data_generation.py
```

**Expected Output**:
```
============================================================
DATA GENERATION TEST
============================================================

[1] Initializing generator...
✓ Generator created

[2] Generating synthetic dataset...
✓ Generated 10 images
  - Images shape: (10, 3, 256, 256)
  - Seg masks shape: (10, 1, 256, 256)
  - Cls labels shape: (10,)
✓ Shapes correct

[3] Verifying data ranges...
  - Images range: [0.00, 255.00]
  - Masks range: [0, 1]
  - Labels range: [0, 3]
✓ Data ranges valid

[4] Checking tissue type distribution...
  - Tumor: 3 (30.0%)
  - Inflammatory: 2 (20.0%)
  - Stroma: 3 (30.0%)
  - Necrosis: 2 (20.0%)
✓ Distribution verified

[5] Visualizing samples...
✓ Visualization saved: test_data_samples.png
```

---

### Test 1.5: Normalization Testing

**Objective**: Verify stain normalization works correctly

**Create test file** `test_normalization.py`:
```python
"""Test stain normalization"""

import sys
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer

print("=" * 60)
print("STAIN NORMALIZATION TEST")
print("=" * 60)

# Generate test data
print("\n[1] Generating test images...")
generator = SyntheticHEImageGenerator(image_size=256)
images, _, _ = generator.generate_dataset(num_images=5)
print(f"✓ Generated {len(images)} images")

# Initialize normalizer
print("\n[2] Fitting normalizer...")
normalizer = ReinhardNormalizer()
normalizer.fit(images[:3])
print("✓ Normalizer fitted on first 3 images")

# Normalize batch
print("\n[3] Normalizing batch...")
normalized_images = normalizer.normalize_batch(images)
print(f"✓ Normalized batch shape: {normalized_images.shape}")

# Verify shapes and ranges
print("\n[4] Verifying output...")
assert normalized_images.shape == images.shape, "Shape mismatch"
assert normalized_images.min() >= 0 and normalized_images.max() <= 255, "Value out of range"
print("✓ Output shape and range valid")

# Visualize before/after
print("\n[5] Visualizing normalization effect...")
fig, axes = plt.subplots(2, 3, figsize=(12, 8))

for i in range(3):
    # Original
    axes[0, i].imshow(images[i].transpose(1, 2, 0).astype(np.uint8))
    axes[0, i].set_title(f"Original {i+1}")
    axes[0, i].axis('off')
    
    # Normalized
    axes[1, i].imshow(normalized_images[i].transpose(1, 2, 0).astype(np.uint8))
    axes[1, i].set_title(f"Normalized {i+1}")
    axes[1, i].axis('off')

plt.suptitle("Stain Normalization Effect")
plt.tight_layout()
plt.savefig('test_normalization.png', dpi=100, bbox_inches='tight')
print("✓ Visualization saved: test_normalization.png")

print("\n" + "=" * 60)
print("✓ NORMALIZATION TEST PASSED")
print("=" * 60)
```

**Run**:
```powershell
python test_normalization.py
```

---

### Test 1.6: Loss Functions Testing

**Objective**: Verify loss functions compute correctly

**Create test file** `test_losses.py`:
```python
"""Test loss functions"""

import sys
from pathlib import Path
import torch

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from federated.federated_utils import DiceLoss

print("=" * 60)
print("LOSS FUNCTIONS TEST")
print("=" * 60)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Test Dice Loss
print("\n[1] Testing Dice Loss...")
dice_loss = DiceLoss()

# Perfect prediction (loss should be ~0)
pred_perfect = torch.ones(2, 1, 32, 32, device=device)
target_perfect = torch.ones(2, 1, 32, 32, device=device)
loss_perfect = dice_loss(pred_perfect, target_perfect)
print(f"  Perfect prediction loss: {loss_perfect:.6f}")
assert loss_perfect < 0.01, "Perfect prediction should have ~0 loss"

# Bad prediction (loss should be ~1)
pred_bad = torch.zeros(2, 1, 32, 32, device=device)
target_bad = torch.ones(2, 1, 32, 32, device=device)
loss_bad = dice_loss(pred_bad, target_bad)
print(f"  Bad prediction loss: {loss_bad:.6f}")
assert loss_bad > 0.9, "Bad prediction should have ~1 loss"

# Partial prediction (loss between 0 and 1)
pred_partial = torch.rand(2, 1, 32, 32, device=device)
target_partial = torch.rand(2, 1, 32, 32, device=device) > 0.5
loss_partial = dice_loss(pred_partial.float(), target_partial.float())
print(f"  Partial prediction loss: {loss_partial:.6f}")
assert 0 <= loss_partial <= 1, "Loss should be between 0 and 1"

print("✓ Dice Loss tests passed")

# Test Classification Loss
print("\n[2] Testing Classification Loss...")
cls_loss = torch.nn.CrossEntropyLoss()

# Perfect prediction
pred_cls_perfect = torch.zeros(4, 4)
pred_cls_perfect[0, 0] = 100  # High confidence in correct class
pred_cls_perfect[1, 1] = 100
pred_cls_perfect[2, 2] = 100
pred_cls_perfect[3, 3] = 100
target_cls_perfect = torch.tensor([0, 1, 2, 3])
loss_cls_perfect = cls_loss(pred_cls_perfect, target_cls_perfect)
print(f"  Perfect prediction loss: {loss_cls_perfect:.6f}")
assert loss_cls_perfect < 0.01, "Perfect prediction should have ~0 loss"

# Partial prediction
pred_cls_partial = torch.randn(4, 4)
target_cls_partial = torch.tensor([0, 1, 2, 3])
loss_cls_partial = cls_loss(pred_cls_partial, target_cls_partial)
print(f"  Partial prediction loss: {loss_cls_partial:.6f}")
assert loss_cls_partial > 0, "Loss should be positive"

print("✓ Classification Loss tests passed")

print("\n" + "=" * 60)
print("✓ LOSS FUNCTIONS TEST PASSED")
print("=" * 60)
```

**Run**:
```powershell
python test_losses.py
```

---

### Test 1.7: Mini Training Test

**Objective**: Verify federated training loop works for 1 round

**Create test file** `test_mini_training.py`:
```python
"""Mini federated training test (1 round, 1 client, 1 epoch)"""

import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from federated.kaggle_training import KaggleTrainer

print("=" * 60)
print("MINI FEDERATED TRAINING TEST")
print("=" * 60)
print("\nConfiguration: 1 round, 1 client, 1 epoch (2 min)")

try:
    trainer = KaggleTrainer()
    model = trainer.train(
        num_rounds=1,
        num_clients=1,
        num_epochs=1,
        batch_size=16,
        learning_rate=0.001
    )
    
    print("\n" + "=" * 60)
    print("✓ MINI TRAINING TEST PASSED")
    print("=" * 60)
    print("\nReady for full training!")
    
except Exception as e:
    print(f"\n✗ Training failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
```

**Run**:
```powershell
python test_mini_training.py
```

---

## Part 2: Testing Checklist

Run these in order:

```powershell
# 1. Validate environment
python validate_project.py

# 2. Test imports
python test_imports.py

# 3. Test model
python test_model.py

# 4. Test data generation
python test_data_generation.py

# 5. Test normalization
python test_normalization.py

# 6. Test losses
python test_losses.py

# 7. Mini training (optional but recommended)
python test_mini_training.py
```

**Expected time**: ~5-10 minutes total

---

## Part 3: Kaggle Testing Steps

### Step 1: Kaggle Notebook - Test Cell 1

```python
# Test Environment
print("Testing Kaggle environment...")

import torch
import numpy as np
import sys

sys.path.insert(0, '/kaggle/input/nuclei-fyp-project/nuclei_fyp_project')

print(f"✓ PyTorch version: {torch.__version__}")
print(f"✓ GPU available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"✓ GPU: {torch.cuda.get_device_name(0)}")

# Test imports
from models.model import MultiTaskUNet
from utils.mock_data_generator import SyntheticHEImageGenerator
from federated.kaggle_training import train_federated_kaggle

print("✓ All imports successful")
```

### Step 2: Kaggle Notebook - Test Cell 2

```python
# Test model instantiation
print("Testing model...")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
model = model.to(device)

total_params = sum(p.numel() for p in model.parameters())
print(f"✓ Model created: {total_params:,} parameters")

# Test forward pass
test_input = torch.randn(1, 3, 256, 256).to(device)
model.eval()
with torch.no_grad():
    seg_out, cls_out = model(test_input)

print(f"✓ Segmentation output shape: {seg_out.shape}")
print(f"✓ Classification output shape: {cls_out.shape}")
print("✓ Model test passed!")
```

### Step 3: Kaggle Notebook - Test Cell 3

```python
# Test data generation
print("Testing data generation...")

generator = SyntheticHEImageGenerator(image_size=256)
images, seg_masks, cls_labels = generator.generate_dataset(num_images=5)

print(f"✓ Generated {len(images)} images")
print(f"✓ Images shape: {images.shape}")
print(f"✓ Masks shape: {seg_masks.shape}")
print(f"✓ Labels shape: {cls_labels.shape}")
print("✓ Data generation test passed!")
```

### Step 4: Kaggle Notebook - Test Cell 4

```python
# Test 1-round mini training
print("Testing mini training (1 round)...")
print("This should complete in ~2-3 minutes...\n")

model = train_federated_kaggle(
    num_rounds=1,
    num_clients=1,
    num_epochs=1,
    batch_size=16
)

print("\n✓ Mini training completed successfully!")
print("Ready for full training with Kaggle GPU!")
```

### Step 5: Kaggle Notebook - Full Training Cell

```python
# Full training
print("Starting full federated training...\n")

model = train_federated_kaggle(
    num_rounds=3,
    num_clients=2,
    num_epochs=2,
    batch_size=8,
    learning_rate=0.001
)

print("\n✓ Full training completed!")
```

---

## Part 4: Testing Scenarios

### Scenario A: "Does inference work?"

```python
"""Test inference pipeline"""
import torch
from models.model import MultiTaskUNet
from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load model
model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
model.to(device).eval()

# Generate test image
generator = SyntheticHEImageGenerator(256)
image, _, _ = generator.generate_dataset(1)

# Normalize
normalizer = ReinhardNormalizer()
normalizer.fit(image)
image_norm = normalizer.normalize_batch(image)

# Convert to tensor and infer
image_tensor = torch.from_numpy(image_norm).unsqueeze(0).float().to(device)

with torch.no_grad():
    seg_pred, cls_pred = model(image_tensor)
    seg_mask = (seg_pred[0, 0] > 0.5).cpu().numpy()
    tissue_class = cls_pred[0].argmax().item()

print(f"✓ Segmentation mask shape: {seg_mask.shape}")
print(f"✓ Predicted tissue class: {tissue_class}")
print("✓ Inference works!")
```

### Scenario B: "Are metrics computing correctly?"

```python
"""Test metrics computation"""
import numpy as np
from federated.federated_utils import SegmentationMetrics, ClassificationMetrics

# Test Dice metric
seg_metric = SegmentationMetrics()
pred = np.random.rand(10, 1, 256, 256) > 0.5
target = np.random.rand(10, 1, 256, 256) > 0.5
dice = seg_metric.dice_coefficient(pred, target)
print(f"✓ Dice score: {dice:.4f} (should be between 0 and 1)")

# Test accuracy metric
cls_metric = ClassificationMetrics()
pred_cls = np.random.randint(0, 4, 100)
target_cls = np.random.randint(0, 4, 100)
acc = cls_metric.accuracy(pred_cls, target_cls)
print(f"✓ Accuracy: {acc:.4f} (should be between 0 and 1)")

print("✓ Metrics work!")
```

### Scenario C: "Can we save and load models?"

```python
"""Test model save/load"""
import torch
from pathlib import Path
from models.model import MultiTaskUNet

# Create model
model1 = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
model1.eval()

# Get initial weights
initial_weights = [p.clone() for p in model1.parameters()]

# Save
save_path = Path('test_model.pth')
torch.save(model1.state_dict(), save_path)
print(f"✓ Model saved: {save_path}")

# Load into new model
model2 = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
model2.load_state_dict(torch.load(save_path))
model2.eval()

# Verify weights
loaded_weights = list(model2.parameters())
for i, (initial, loaded) in enumerate(zip(initial_weights, loaded_weights)):
    assert torch.allclose(initial, loaded), f"Weight mismatch at layer {i}"

print("✓ Model saved and loaded correctly")

# Cleanup
save_path.unlink()
print("✓ Model save/load works!")
```

---

## Part 5: Performance Benchmarking

### Benchmark 1: Data Generation Speed

```python
import time
from utils.mock_data_generator import SyntheticHEImageGenerator

generator = SyntheticHEImageGenerator(256)

print("Data Generation Speed Test:")
for num_images in [10, 50, 100]:
    start = time.time()
    images, _, _ = generator.generate_dataset(num_images)
    elapsed = time.time() - start
    per_image = elapsed / num_images
    print(f"  {num_images} images: {elapsed:.2f}s ({per_image*1000:.0f}ms per image)")
```

**Expected**:
```
Data Generation Speed Test:
  10 images: 2.34s (234ms per image)
  50 images: 11.45s (229ms per image)
  100 images: 22.89s (229ms per image)
```

### Benchmark 2: Forward Pass Speed

```python
import torch
import time
from models.model import MultiTaskUNet

model = MultiTaskUNet(in_channels=3, out_channels_seg=1, out_channels_cls=4, depth=4)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device).eval()

print(f"Forward Pass Speed Test ({device}):")
for batch_size in [1, 4, 8, 16]:
    x = torch.randn(batch_size, 3, 256, 256).to(device)
    
    # Warmup
    with torch.no_grad():
        _ = model(x)
    
    # Benchmark
    torch.cuda.synchronize() if device.type == "cuda" else None
    start = time.time()
    
    with torch.no_grad():
        for _ in range(10):
            _ = model(x)
    
    torch.cuda.synchronize() if device.type == "cuda" else None
    elapsed = time.time() - start
    per_image = elapsed / (10 * batch_size)
    
    print(f"  Batch {batch_size}: {elapsed:.3f}s ({per_image*1000:.1f}ms per image)")
```

**Expected** (GPU):
```
Forward Pass Speed Test (cuda):
  Batch 1: 0.234s (23.4ms per image)
  Batch 4: 0.456s (11.4ms per image)
  Batch 8: 0.823s (10.3ms per image)
  Batch 16: 1.654s (10.3ms per image)
```

---

## Part 6: Troubleshooting Tests

### Test: "GPU not detected?"

```python
import torch

print(f"PyTorch version: {torch.__version__}")
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"CUDA version: {torch.version.cuda}")
print(f"cuDNN version: {torch.backends.cudnn.version()}")

if torch.cuda.is_available():
    print(f"GPU count: {torch.cuda.device_count()}")
    for i in range(torch.cuda.device_count()):
        print(f"  GPU {i}: {torch.cuda.get_device_name(i)}")
        print(f"    Memory: {torch.cuda.get_device_properties(i).total_memory / 1e9:.1f} GB")
else:
    print("WARNING: No GPU detected! Training will be slow on CPU.")
```

### Test: "Out of memory?"

```python
import torch
import gc

print(f"Memory before cleanup: {torch.cuda.memory_allocated() / 1e9:.2f} GB")

# Clear cache
torch.cuda.empty_cache()
gc.collect()

print(f"Memory after cleanup: {torch.cuda.memory_allocated() / 1e9:.2f} GB")
```

---

## Part 7: Success Criteria

All tests should pass before production deployment:

- ✅ Environment validation passes
- ✅ All imports successful
- ✅ Model instantiates and forward pass works
- ✅ Data generation creates correct shapes
- ✅ Normalization produces valid outputs
- ✅ Loss functions compute reasonable values
- ✅ Mini training completes without errors
- ✅ Inference pipeline works end-to-end
- ✅ Metrics compute correctly
- ✅ Model save/load works
- ✅ Performance meets expectations

If all pass → **Ready for Kaggle training!**

