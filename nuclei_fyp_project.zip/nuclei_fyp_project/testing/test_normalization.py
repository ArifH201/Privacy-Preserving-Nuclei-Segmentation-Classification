"""Test stain normalization"""

import sys
from pathlib import Path
import numpy as np

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from utils.mock_data_generator import SyntheticHEImageGenerator
from utils.normalization import ReinhardNormalizer

print("=" * 60)
print("STAIN NORMALIZATION TEST")
print("=" * 60)

# Generate test data
print("\n[1] Generating test images...")
generator = SyntheticHEImageGenerator(image_size=256)
images, _, _ = generator.generate_dataset(num_images=5)
print(f"✓ Generated {len(images)} images")

# Initialize normalizer
print("\n[2] Fitting normalizer...")
normalizer = ReinhardNormalizer()
normalizer.fit(images[:3])
print("✓ Normalizer fitted on first 3 images")

# Normalize batch
print("\n[3] Normalizing batch...")
normalized_images = normalizer.normalize_batch(images)
print(f"✓ Normalized batch shape: {normalized_images.shape}")

# Verify shapes and ranges
print("\n[4] Verifying output...")
assert normalized_images.shape == images.shape, "Shape mismatch"
assert normalized_images.min() >= 0 and normalized_images.max() <= 255, "Value out of range"
print("✓ Output shape and range valid")

# Check normalization effect
print("\n[5] Analyzing normalization effect...")
orig_mean = images.mean(axis=(2, 3))
norm_mean = normalized_images.mean(axis=(2, 3))
print(f"  - Original image means: {orig_mean}")
print(f"  - Normalized image means: {norm_mean}")
print("✓ Normalization applied successfully")

print("\n" + "=" * 60)
print("✓ NORMALIZATION TEST PASSED")
print("=" * 60)
