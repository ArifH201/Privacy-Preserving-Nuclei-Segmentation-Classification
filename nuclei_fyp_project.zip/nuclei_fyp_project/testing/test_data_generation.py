"""Test synthetic H&E data generation"""

import sys
from pathlib import Path
import numpy as np

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from utils.mock_data_generator import SyntheticHEImageGenerator

print("=" * 60)
print("DATA GENERATION TEST")
print("=" * 60)

# Initialize generator
print("\n[1] Initializing generator...")
generator = SyntheticHEImageGenerator(image_size=256)
print("✓ Generator created")

# Generate sample dataset
print("\n[2] Generating synthetic dataset...")
images, seg_masks, cls_labels = generator.generate_dataset(
    num_images=10,
    tissue_type_dist=[0.3, 0.2, 0.3, 0.2]
)

print(f"✓ Generated {len(images)} images")
print(f"  - Images shape: {images.shape}")
print(f"  - Seg masks shape: {seg_masks.shape}")
print(f"  - Cls labels shape: {cls_labels.shape}")

# Verify shapes
assert images.shape == (10, 3, 256, 256), f"Wrong images shape: {images.shape}"
assert seg_masks.shape == (10, 1, 256, 256), f"Wrong masks shape: {seg_masks.shape}"
assert cls_labels.shape == (10,), f"Wrong labels shape: {cls_labels.shape}"
print("✓ Shapes correct")

# Verify data ranges
print("\n[3] Verifying data ranges...")
print(f"  - Images range: [{images.min():.2f}, {images.max():.2f}]")
print(f"  - Masks range: [{seg_masks.min()}, {seg_masks.max()}]")
print(f"  - Labels range: [{cls_labels.min()}, {cls_labels.max()}]")

assert images.min() >= 0 and images.max() <= 255, "Images out of range"
assert seg_masks.min() >= 0 and seg_masks.max() <= 1, "Masks out of range"
assert cls_labels.min() >= 0 and cls_labels.max() < 4, "Labels out of range"
print("✓ Data ranges valid")

# Tissue type distribution
print("\n[4] Checking tissue type distribution...")
tissue_names = ['Tumor', 'Inflammatory', 'Stroma', 'Necrosis']
for tissue_id in range(4):
    count = np.sum(cls_labels == tissue_id)
    pct = 100 * count / len(cls_labels)
    print(f"  - {tissue_names[tissue_id]}: {count} ({pct:.1f}%)")
print("✓ Distribution verified")

print("\n" + "=" * 60)
print("✓ DATA GENERATION TEST PASSED")
print("=" * 60)
