"""Test model architecture and forward pass"""

import sys
from pathlib import Path
import torch

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from models.model import MultiTaskUNet

print("=" * 60)
print("MODEL ARCHITECTURE TEST")
print("=" * 60)

# Initialize model
print("\n[1] Instantiating model...")
model = MultiTaskUNet(
    in_channels=3,
    out_channels_seg=1,
    out_channels_cls=4,
    depth=4
)
print("✓ Model created")

# Check parameter count
total_params = sum(p.numel() for p in model.parameters())
print(f"✓ Total parameters: {total_params:,}")
print(f"✓ Model size: ~{total_params * 4 / 1e6:.1f} MB")

# Test forward pass
print("\n[2] Testing forward pass...")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)
model.eval()

# Input: batch_size=2, channels=3, height=256, width=256
test_input = torch.randn(2, 3, 256, 256).to(device)

try:
    with torch.no_grad():
        seg_out, cls_out = model(test_input)
    
    print(f"✓ Segmentation output shape: {seg_out.shape}")
    print(f"✓ Classification output shape: {cls_out.shape}")
    
    # Verify shapes
    assert seg_out.shape == (2, 1, 256, 256), f"Wrong seg output: {seg_out.shape}"
    assert cls_out.shape == (2, 4), f"Wrong cls output: {cls_out.shape}"
    print("✓ Output shapes correct")
    
except Exception as e:
    print(f"✗ Forward pass failed: {e}")
    sys.exit(1)

# Test gradient flow
print("\n[3] Testing gradient flow...")
model.train()
test_input_grad = torch.randn(2, 3, 256, 256, requires_grad=True, device=device)
seg_out, cls_out = model(test_input_grad)

try:
    loss = seg_out.mean() + cls_out.mean()
    loss.backward()
    print("✓ Backpropagation successful")
    print(f"✓ Input gradients shape: {test_input_grad.grad.shape}")
except Exception as e:
    print(f"✗ Backpropagation failed: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("✓ MODEL TEST PASSED")
print("=" * 60)
