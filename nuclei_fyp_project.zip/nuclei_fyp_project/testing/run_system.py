"""
Master Script to Launch Federated Learning System (One-Click Demo).

This script automatically:
1. Starts the Flower server on localhost:8080
2. Launches 2 federated learning clients with different data
3. Monitors the federated learning rounds
4. Saves the final global model
5. Provides instructions for running the Streamlit dashboard

USAGE:
    python run_system.py [--num_rounds 5] [--num_clients 2]

PRIVACY PROTECTION:
- Each client trains on private local data
- Only model weights are shared with server
- Training data never leaves the client
"""

import subprocess
import time
import sys
import argparse
import signal
from pathlib import Path
from typing import List
import platform


class FederatedLearningDemo:
    """Orchestrate federated learning demo with server and clients."""
    
    def __init__(self, num_rounds: int = 5, num_clients: int = 2, server_address: str = "127.0.0.1:8080"):
        """
        Initialize federated learning demo.
        
        Args:
            num_rounds: Number of federated learning rounds
            num_clients: Number of client processes to launch
            server_address: Server address in format host:port
        """
        self.num_rounds = num_rounds
        self.num_clients = num_clients
        self.server_address = server_address
        
        self.project_root = Path(__file__).parent
        self.server_process = None
        self.client_processes = []
        
        # Detect OS
        self.is_windows = platform.system() == "Windows"
        self.is_linux = platform.system() == "Linux"
        self.is_mac = platform.system() == "Darwin"
    
    def log(self, message: str, level: str = "INFO"):
        """Print formatted log message."""
        colors = {
            "INFO": "\033[94m",      # Blue
            "SUCCESS": "\033[92m",   # Green
            "WARNING": "\033[93m",   # Yellow
            "ERROR": "\033[91m",     # Red
            "RESET": "\033[0m"       # Reset
        }
        
        color = colors.get(level, colors["INFO"])
        reset = colors["RESET"]
        
        # Windows doesn't support ANSI colors
        if self.is_windows:
            color = reset = ""
        
        timestamp = time.strftime("%H:%M:%S")
        print(f"{color}[{timestamp}] [{level}] {message}{reset}")
    
    def check_dependencies(self) -> bool:
        """
        Check if all required dependencies are installed.
        
        Returns:
            True if all dependencies available, False otherwise
        """
        self.log("Checking dependencies...", "INFO")
        
        required_packages = [
            ('torch', 'PyTorch'),
            ('flwr', 'Flower'),
            ('numpy', 'NumPy'),
            ('cv2', 'OpenCV'),
        ]
        
        missing = []
        for module, name in required_packages:
            try:
                __import__(module)
                self.log(f"  ✓ {name}", "SUCCESS")
            except ImportError:
                self.log(f"  ✗ {name} NOT FOUND", "ERROR")
                missing.append(name)
        
        if missing:
            self.log(f"Missing packages: {', '.join(missing)}", "ERROR")
            self.log("Install with: pip install -r requirements.txt", "WARNING")
            return False
        
        self.log("All dependencies available!", "SUCCESS")
        return True
    
    def start_server(self):
        """Start the Flower server process."""
        self.log("Starting Flower Server...", "INFO")
        
        server_script = self.project_root / "federated" / "server.py"
        
        if not server_script.exists():
            self.log(f"Server script not found: {server_script}", "ERROR")
            return False
        
        # Build command
        cmd = [
            sys.executable,
            str(server_script),
            f"--server_address={self.server_address}",
            f"--num_rounds={self.num_rounds}",
            f"--min_fit_clients={self.num_clients}",
            f"--min_evaluate_clients={self.num_clients}",
            f"--min_available_clients={self.num_clients}"
        ]
        
        try:
            # Start server process
            self.server_process = subprocess.Popen(
                cmd,
                cwd=self.project_root,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                bufsize=1
            )
            
            self.log(f"Server started (PID: {self.server_process.pid})", "SUCCESS")
            self.log(f"Server listening on {self.server_address}", "INFO")
            
            # Wait for server to be ready
            time.sleep(3)
            return True
        
        except Exception as e:
            self.log(f"Failed to start server: {e}", "ERROR")
            return False
    
    def start_clients(self):
        """Start client processes."""
        self.log(f"Starting {self.num_clients} Federated Learning Clients...", "INFO")
        
        client_script = self.project_root / "federated" / "client.py"
        
        if not client_script.exists():
            self.log(f"Client script not found: {client_script}", "ERROR")
            return False
        
        for client_id in range(self.num_clients):
            # Build command
            cmd = [
                sys.executable,
                str(client_script),
                f"--client_id={client_id}",
                f"--server_address={self.server_address}",
                f"--num_epochs=3",
                f"--learning_rate=0.001"
            ]
            
            try:
                # Start client process
                process = subprocess.Popen(
                    cmd,
                    cwd=self.project_root,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    universal_newlines=True,
                    bufsize=1
                )
                
                self.client_processes.append(process)
                self.log(f"Client {client_id} started (PID: {process.pid})", "SUCCESS")
                
                # Stagger client starts
                time.sleep(2)
            
            except Exception as e:
                self.log(f"Failed to start client {client_id}: {e}", "ERROR")
                return False
        
        return True
    
    def monitor_processes(self):
        """Monitor server and client processes during execution."""
        self.log("Federated Learning in Progress...", "INFO")
        self.log("=" * 60, "INFO")
        
        try:
            # Wait for server to complete
            if self.server_process:
                self.server_process.wait()
            
            # Wait for all clients to complete
            for i, client in enumerate(self.client_processes):
                client.wait()
                self.log(f"Client {i} completed", "SUCCESS")
        
        except KeyboardInterrupt:
            self.log("\nInterrupt received, shutting down...", "WARNING")
            self.cleanup()
            sys.exit(0)
    
    def cleanup(self):
        """Terminate all processes gracefully."""
        self.log("Cleaning up processes...", "INFO")
        
        # Terminate server
        if self.server_process and self.server_process.poll() is None:
            self.log("Terminating server...", "WARNING")
            self.server_process.terminate()
            try:
                self.server_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.log("Force killing server...", "WARNING")
                self.server_process.kill()
        
        # Terminate clients
        for i, client in enumerate(self.client_processes):
            if client.poll() is None:
                self.log(f"Terminating client {i}...", "WARNING")
                client.terminate()
                try:
                    client.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self.log(f"Force killing client {i}...", "WARNING")
                    client.kill()
        
        self.log("Cleanup complete", "SUCCESS")
    
    def print_summary(self):
        """Print system summary after completion."""
        self.log("\n" + "=" * 60, "SUCCESS")
        self.log("FEDERATED LEARNING DEMO COMPLETE!", "SUCCESS")
        self.log("=" * 60, "SUCCESS")
        
        print("""
📊 SUMMARY:
  ✓ Server aggregated model weights from {} clients
  ✓ Completed {} federated learning rounds
  ✓ Global model saved to: models/global_weights.pth
  
🔒 PRIVACY GUARANTEES:
  ✓ Training data stayed on client devices
  ✓ Only model weights were shared with server
  ✓ No patient data exposed
  
📈 NEXT STEPS:
  1. View results in the Jupyter notebook:
     jupyter notebook nuclei_fyp_project/notebooks/testing_and_visualization.ipynb
  
  2. Launch the interactive dashboard:
     streamlit run nuclei_fyp_project/ui/streamlit_app.py
  
  3. Check model weights:
     ls -lh nuclei_fyp_project/models/global_weights.pth
  
📁 PROJECT STRUCTURE:
  nuclei_fyp_project/
  ├── federated/          # Federated learning code
  │   ├── server.py      # Flower server
  │   ├── client.py      # Flower clients
  │   └── federated_utils.py
  ├── models/            # Trained models
  │   └── global_weights.pth
  ├── notebooks/         # Jupyter notebooks
  │   └── testing_and_visualization.ipynb
  ├── ui/               # Streamlit dashboard
  │   └── streamlit_app.py
  └── utils/            # Utility modules
        """.format(self.num_clients, self.num_rounds))
        
        self.log("Thank you for using Privacy-Preserving Nuclei Segmentation!", "SUCCESS")
    
    def run(self):
        """Run the complete federated learning demo."""
        print("""
╔════════════════════════════════════════════════════════════════════╗
║   Privacy-Preserving Nuclei Segmentation & Classification          ║
║   Using Federated Learning - Demo System                           ║
╚════════════════════════════════════════════════════════════════════╝
        """)
        
        # Check dependencies
        if not self.check_dependencies():
            self.log("Please install missing dependencies and try again.", "ERROR")
            return False
        
        # Start server
        if not self.start_server():
            return False
        
        # Start clients
        if not self.start_clients():
            self.cleanup()
            return False
        
        # Monitor execution
        try:
            self.monitor_processes()
        except Exception as e:
            self.log(f"Error during execution: {e}", "ERROR")
            self.cleanup()
            return False
        
        # Print summary
        self.print_summary()
        
        return True


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Federated Learning Demo for Nuclei Segmentation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
EXAMPLES:
  python run_system.py
  python run_system.py --num_rounds 10
  python run_system.py --num_rounds 5 --num_clients 3
  python run_system.py --server_address 192.168.1.100:8080
        """
    )
    
    parser.add_argument(
        '--num_rounds',
        type=int,
        default=5,
        help='Number of federated learning rounds (default: 5)'
    )
    
    parser.add_argument(
        '--num_clients',
        type=int,
        default=2,
        help='Number of client processes (default: 2)'
    )
    
    parser.add_argument(
        '--server_address',
        type=str,
        default='127.0.0.1:8080',
        help='Server address in format host:port (default: 127.0.0.1:8080)'
    )
    
    args = parser.parse_args()
    
    # Create and run demo
    demo = FederatedLearningDemo(
        num_rounds=args.num_rounds,
        num_clients=args.num_clients,
        server_address=args.server_address
    )
    
    success = demo.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
