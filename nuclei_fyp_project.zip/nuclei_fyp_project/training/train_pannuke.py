"""
Centralized training script for PanNuke dataset.

This script trains the MultiTask U-Net model using:
- PanNuke dataset
- Multi-class segmentation (6 classes)
- Multi-task loss (segmentation + classification)

Output:
Saved trained model → models/pannuke_trained.pth
"""

import os
import torch
from torch.utils.data import DataLoader
from torch.optim import Adam

from models.model import create_model
from utils.pannuke_dataset import PanNukeDataset
from federated.federated_utils import CombinedLoss, SegmentationMetrics, ClassificationMetrics

from torch.cuda.amp import autocast, GradScaler
import numpy as np

# Enable cuDNN auto-tuner for faster GPU performance
torch.backends.cudnn.benchmark = True


# ==============================
# Training Configuration
# ==============================

DATASET_PATH = "dataset"
BATCH_SIZE = 4
EPOCHS = 10
LEARNING_RATE = 1e-4

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Using device:", DEVICE)


# ==============================
# Load Dataset
# ==============================

print("Loading PanNuke dataset...")

dataset = PanNukeDataset(
    images_path=os.path.join(DATASET_PATH, "images.npy"),
    masks_path=os.path.join(DATASET_PATH, "masks.npy"),
    types_path=os.path.join(DATASET_PATH, "types.npy")
)

train_loader = DataLoader(
    dataset,
    batch_size=BATCH_SIZE,
    shuffle=True,
    num_workers=2,
    pin_memory=True
)

print(f"Dataset size: {len(dataset)}")


# ==============================
# Create Model
# ==============================

model = create_model()
model = model.to(DEVICE)

print(f"Model parameters: {model.get_parameter_count():,}")


# ==============================
# Loss + Optimizer
# ==============================

criterion = CombinedLoss()

optimizer = Adam(
    model.parameters(),
    lr=LEARNING_RATE
)

# Mixed precision scaler (safe for CPU or GPU)
scaler = GradScaler(enabled=torch.cuda.is_available())


# ==============================
# Training Loop
# ==============================

print("Starting training...")

for epoch in range(EPOCHS):

    model.train()

    epoch_loss = 0
    dice_scores = []
    accuracies = []

    for images, masks, cls_labels in train_loader:

        images = images.to(DEVICE)
        masks = masks.to(DEVICE)
        cls_labels = cls_labels.to(DEVICE)

        # Fake classification labels (PanNuke example)
       # cls_labels = torch.randint(0, 4, (images.shape[0],)).to(DEVICE)

        optimizer.zero_grad()

        # Forward pass with mixed precision
        with autocast():

            seg_out, cls_out = model(images)

            loss, loss_dict = criterion(
                seg_out,
                masks,
                cls_out,
                cls_labels
            )

        # Backpropagation
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        epoch_loss += loss.item()

        # ==============================
        # Compute Metrics
        # ==============================

        seg_pred = seg_out.detach().cpu().numpy()
        seg_target = masks.detach().cpu().numpy()

        for pred, target in zip(seg_pred, seg_target):

            dice = SegmentationMetrics.dice_coefficient(pred, target)
            dice_scores.append(dice)

        cls_pred = cls_out.argmax(dim=1).detach().cpu().numpy()
        cls_target = cls_labels.detach().cpu().numpy()

        acc = ClassificationMetrics.accuracy(cls_pred, cls_target)
        accuracies.append(acc)

    avg_loss = epoch_loss / len(train_loader)
    avg_dice = np.mean(dice_scores)
    avg_acc = np.mean(accuracies)

    print(
        f"Epoch {epoch+1}/{EPOCHS} | "
        f"Loss: {avg_loss:.4f} | "
        f"Dice: {avg_dice:.4f} | "
        f"Accuracy: {avg_acc:.4f}"
    )


# ==============================
# Save Model
# ==============================

os.makedirs("models", exist_ok=True)

MODEL_PATH = "models/pannuke_trained.pth"

torch.save(model.state_dict(), MODEL_PATH)

print(f"\nModel saved to {MODEL_PATH}")