"""
Streamlit Dashboard for Pathologists.

Interactive dashboard for:
- Uploading H&E histopathology images
- Running inference with the federated model
- Visualizing segmentation masks and classification results
- Side-by-side comparison of original and processed images
"""

import sys
from pathlib import Path

import streamlit as st
import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
import plotly.graph_objects as go

# Add parent directory to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from models.model import create_model
from utils.normalization import ReinhardNormalizer
from federated.federated_utils import SegmentationMetrics
from utils.mock_data_generator import SyntheticHEImageGenerator


# ==================== Page Configuration ====================

st.set_page_config(
    page_title="Nuclei Segmentation & Classification",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
    .main { padding: 0rem 0rem; }
    .stMetric { background: #f0f2f6; padding: 1rem; border-radius: 0.5rem; }
</style>
""", unsafe_allow_html=True)


# ==================== Session State ====================

@st.cache_resource
def load_model():
    # Load trained model (cached for efficiency)
    model = create_model(num_classes=19)
    
    # Try to load pre-trained weights
    model_path = Path(__file__).parent.parent / 'models' / 'pannuke_trained_.pth'
    if model_path.exists():
        model.load_state_dict(torch.load(model_path, map_location='cpu'))
        st.success("Loaded trained pannuke model! ")
    else:
        st.warning("Trained model not found. Using random weights.")
    
    model.eval()
    return model


@st.cache_resource
def load_normalizer():
    """Load stain normalizer (cached)."""
    return ReinhardNormalizer()


def preprocess_image(image: np.ndarray, target_size: int = 256) -> torch.Tensor:
    """
    Preprocess image for model inference.
    
    Args:
        image: Input image (H, W, 3) uint8 RGB
        target_size: Target size for model
        
    Returns:
        Tensor ready for model (1, 3, H, W)
    """
    # Resize
    image = cv2.resize(image, (target_size, target_size), interpolation=cv2.INTER_LINEAR)
    
    # Normalize to [0, 1]
    image = image.astype(np.float32) / 255.0
    
    # Convert to tensor and add batch dimension
    image_tensor = torch.from_numpy(image).permute(2, 0, 1).unsqueeze(0)
    
    return image_tensor



def run_inference(image_tensor: torch.Tensor, model: nn.Module) -> tuple:
    """
    Run model inference on image.
    
    Args:
        image_tensor: Preprocessed image tensor
        model: Model to use
        
    Returns:
        (segmentation_mask, class_probs, predicted_class)
    """
    device = next(model.parameters()).device
    image_tensor = image_tensor.to(device)

    with torch.no_grad():
        seg_output, cls_output = model(image_tensor)
        
        #  segmentation pridiction 
        seg_mask = torch.argmax(seg_output, dim=1)[0].cpu().numpy()  # (H, W) binary mask
        
        # Get classification probabilities
        cls_probs = F.softmax(cls_output, dim=1)[0].cpu().numpy()
        predicted_class = int(cls_probs.argmax())
        
    return seg_mask, cls_probs, predicted_class


def create_overlay_image(
    original: np.ndarray,
    mask: np.ndarray,
    alpha: float = 0.5
) -> np.ndarray:
    """
    Create overlay of segmentation mask on original image.
    
    Args:
        original: Original image (H, W, 3) in [0, 255]
        mask: Segmentation mask (H, W) in [0, 1]
        alpha: Transparency of overlay
        
    Returns:
        Overlaid image (H, W, 3)
    """
    # Create colored mask (green for nuclei)
    colored_mask = np.zeros_like(original)

    #assign color to every mask
    colored_mask[mask == 1] = [255, 0, 0]  # Red for neoplastic
    colored_mask[mask == 2] = [0, 0, 255]  # Blue for inflammatory
    colored_mask[mask == 3] = [255, 255, 0] # Yellow for connective
    colored_mask[mask == 4] = [255, 0, 255] # Magenta for dead
    colored_mask[mask == 5] = [0, 255, 255] # Cyan for epithelial
    
    # Blend
    overlay = cv2.addWeighted(original, 1 - alpha, colored_mask, alpha, 0)
    
    return overlay

def get_nucllei_presence(mask):

    """check which nuclei classes are present in segmentation mask . 
     return tabloe-friendly content indicating which classes are present"""
    nuclei_classes = {
        1: "Neoplastic",
        2: "Inflammatory",
        3: "Connective",
        4: "Dead",
        5: "Epithelial"
    }
    results = []
    for cls_id, cls_name in nuclei_classes.items():
        presence = "✅" if np.any(mask == cls_id) else "❌"
        results.append(f"{cls_name}: {presence}")
    return results

def create_classification_viz(tissue_names: list, class_probs: np.ndarray) -> go.Figure:
    """Create classification probability bar chart."""
    fig = go.Figure(
        data=[go.Bar(x=tissue_names, y=class_probs, marker_color='indianred')]
    )
    fig.update_layout(
        title="Tissue Classification Probabilities",
        xaxis_title="Tissue Type",
        yaxis_title="Probability",
        height=400
    )
    return fig


def create_metrics_comparison(
    seg_mask: np.ndarray,
    reference_mask: np.ndarray
) -> dict:
    """Compute metrics comparing prediction to reference."""
    dice = SegmentationMetrics.dice_coefficient(seg_mask, reference_mask)
    jaccard = SegmentationMetrics.jaccard_index(seg_mask, reference_mask)
    
    return {
        'Dice Coefficient': dice,
        'Jaccard Index': jaccard
    }


# ==================== Main App ====================

def main():
    """Main Streamlit app."""
    
    # Title and description
    st.title("🔬 Privacy-Preserving Nuclei Segmentation & Classification")
    st.markdown("""
    **Federated Learning System for H&E Histopathology**
    
    This dashboard demonstrates:
    - **Segmentation**: Binary masks for nuclei regions
    - **Classification**: 19-class tissue type identification (PanNuke dataset)
    - **Privacy**: Only model weights shared, never training data
    """)
    
    # Load model and normalizer
    model = load_model()
    normalizer = load_normalizer()
    
    
    tissue_names = [ "Adrenal_gland","Bile-duct","Bladder","Breast","Cervix",
        "Colon","Esophagus","HeadNeck","Kidney","Liver",
        "Lung","Ovarian","Pancreatic","Prostate","Skin",
        "Stomach","Testis","Thyroid","Uterus"
        ]
    
    # Sidebar controls
    st.sidebar.header("⚙️ Settings")
    
    image_source = st.sidebar.radio(
        "Image Source:",
        ["Upload Image", "Generate Synthetic", "Demo Sample"]
    )
    
    alpha_blend = st.sidebar.slider(
        "Mask Overlay Transparency:",
        min_value=0.0, max_value=1.0, value=0.5
    )
    
    show_metrics = st.sidebar.checkbox("Show Segmentation Metrics", value=True)
    
    # Main content
    col1, col2 = st.columns(2)
    
    # Get input image
    if image_source == "Upload Image":
        uploaded_file = st.file_uploader("Choose an image...", type=['jpg', 'png', 'tif'])
        
        if uploaded_file is None:
            st.info("👉 Upload an H&E histopathology image to get started")
            return
        
        image_pil = Image.open(uploaded_file)
        image_np = np.array(image_pil)
        
        if len(image_np.shape) == 2:
            image_np = cv2.cvtColor(image_np, cv2.COLOR_GRAY2RGB)
        elif image_np.shape[2] == 4:
            image_np = cv2.cvtColor(image_np, cv2.COLOR_RGBA2RGB)
    
    elif image_source == "Generate Synthetic":
        st.sidebar.subheader("Synthetic Image Settings")
        tissue_type = st.sidebar.selectbox(
            "Tissue Type:",
            [0, 1, 2, 3],
            format_func=lambda x: tissue_names[x]
        )
        
        if st.sidebar.button("Generate Image"):
            generator = SyntheticHEImageGenerator(image_size=256)
            image_np, ref_mask = generator.generate_image_and_mask(tissue_type)
            st.session_state['generated_image'] = image_np
            st.session_state['reference_mask'] = ref_mask / 255.0
        
        if 'generated_image' not in st.session_state:
            st.info("Click 'Generate Image' to create synthetic data")
            return
        
        image_np = st.session_state['generated_image']
    
    else:  # Demo Sample
        generator = SyntheticHEImageGenerator(image_size=256)
        image_np, ref_mask = generator.generate_image_and_mask(np.random.randint(0, 4))
        st.session_state['reference_mask'] = ref_mask / 255.0
    
    # Apply stain normalization
    image_normalized = image_np
    
    # Run inference
    image_tensor = preprocess_image(image_normalized)
    seg_mask, cls_probs, predicted_class = run_inference(image_tensor, model)
    
    # Resize mask back to original size
    seg_mask = seg_mask.astype(np.uint8)
    seg_mask_resized = cv2.resize(seg_mask, (image_np.shape[1], image_np.shape[0]))
    
    # Create overlay
    overlay = create_overlay_image(image_np, seg_mask_resized, alpha_blend)
    
    # Display results
    with col1:
        st.subheader("📷 Original Image")
        st.image(image_np, use_column_width=True)
    
    with col2:
        st.subheader("🎯 Segmentation Results")
        st.image(overlay, use_column_width=True)
    
    # Classification results
    st.subheader("🧬 Tissue Classification")

    #show pridected tissue clearly
    st.success(f"Predicted Tissue Type: **{tissue_names[predicted_class]}**")

    # show confidence
    confidence = cls_probs[predicted_class]*100
    st.info(f"Model Confidence: **{confidence:.2f}%**")
    
    #show number of detected nuclei pixels
    num_nuclei_pixels = np.sum(seg_mask > 0)
    st.info(f"Number of Detected Nuclei Pixels: **{num_nuclei_pixels}**")

    fig_cls = create_classification_viz(tissue_names, cls_probs)
    st.plotly_chart(fig_cls, use_container_width=True)
    
    # nuclei type presence table
    st.subheader("🔍 Nuclei Type Presence")

    nuclei_presence = get_nucllei_presence(seg_mask_resized)
    st.table(nuclei_presence)


    # Segmentation metrics
    if show_metrics and 'reference_mask' in st.session_state:
        st.subheader("📊 Segmentation Quality Metrics")
        metrics = create_metrics_comparison(seg_mask_resized, st.session_state['reference_mask'])
        st.metric("Dice Coefficient", f"{metrics['Dice Coefficient']:.3f}")
        st.metric("Jaccard Index", f"{metrics['Jaccard Index']:.3f}")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    **Privacy Notice**: This system operates on federated learning principles:
    - 🔒 Training data never leaves local clients
    - 🔐 Only model weights are shared with the server
    - ✅ Evaluated on multiple hospitals' data without centralized data collection
    """)


if __name__ == "__main__":
    main()  