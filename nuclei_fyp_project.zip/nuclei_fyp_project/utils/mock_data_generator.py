"""
Mock Data Generator for Federated Learning Demonstration.

Generates synthetic H&E histopathology images and corresponding masks
to enable demonstration without requiring large datasets.

The generated images mimic real H&E staining patterns:
- Purple: Nuclei (hematoxylin staining)
- Pink: Cytoplasm and extracellular matrix (eosin staining)
- Different tissue types represented by label classes
"""

import numpy as np
import cv2
from typing import Tuple, List, Optional
from pathlib import Path
from skimage import draw
import random


class SyntheticHEImageGenerator:
    """Generate synthetic H&E histopathology images with nuclei masks."""

    def __init__(self, image_size: int = 256, seed: int = 42):
        self.image_size = image_size
        self.seed = seed
        np.random.seed(seed)
        random.seed(seed)

    def _create_he_background(self, tissue_type: int) -> np.ndarray:
        """Create H&E stained tissue background."""
        bg = np.ones((self.image_size, self.image_size, 3), dtype=np.uint8)

        if tissue_type == 0:        # Tumor
            bg[:] = [240, 200, 220]
        elif tissue_type == 1:      # Inflammatory
            bg[:] = [245, 210, 215]
        elif tissue_type == 2:      # Stroma
            bg[:] = [250, 220, 210]
        else:                       # Necrosis
            bg[:] = [240, 240, 235]

        noise = np.random.normal(0, 5, bg.shape)
        bg = np.clip(bg.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        return bg

    def _draw_nuclei(self, image: np.ndarray, mask: np.ndarray, tissue_type: int) -> None:
        """Draw nuclei on image and mask."""
        if tissue_type == 0:
            num_nuclei = np.random.randint(40, 70)
        elif tissue_type == 1:
            num_nuclei = np.random.randint(60, 100)
        elif tissue_type == 2:
            num_nuclei = np.random.randint(10, 30)
        else:
            num_nuclei = np.random.randint(1, 10)

        for _ in range(num_nuclei):
            cx = np.random.randint(10, self.image_size - 10)
            cy = np.random.randint(10, self.image_size - 10)
            radius = np.random.randint(3, 8)

            rr, cc = draw.disk((cy, cx), radius, shape=image.shape[:2])

            hue_var = np.random.randint(-10, 10)
            nuc_color = np.clip(
                np.array([150 + hue_var, 100 + hue_var, 180 + hue_var]),
                0, 255
            ).astype(np.uint8)

            image[rr, cc] = nuc_color
            mask[rr, cc] = 255

    def _draw_tissue_structures(self, image: np.ndarray, tissue_type: int) -> None:
        """Draw tissue-specific structures."""
        if tissue_type == 0:  # Tumor
            for _ in range(3):
                x = np.random.randint(20, self.image_size - 20)
                y = np.random.randint(20, self.image_size - 20)
                cv2.ellipse(image, (x, y), (30, 20), 45, 0, 360, (200, 150, 180), 2)

        elif tissue_type == 2:  # Stroma
            for _ in range(5):
                pt1 = (np.random.randint(0, self.image_size), np.random.randint(0, self.image_size))
                pt2 = (np.random.randint(0, self.image_size), np.random.randint(0, self.image_size))
                cv2.line(image, pt1, pt2, (220, 160, 140), 1)

    def generate_image_and_mask(self, tissue_type: int = 0) -> Tuple[np.ndarray, np.ndarray]:
        """Generate one synthetic image and mask."""
        image = self._create_he_background(tissue_type)
        mask = np.zeros((self.image_size, self.image_size), dtype=np.uint8)

        self._draw_nuclei(image, mask, tissue_type)
        self._draw_tissue_structures(image, tissue_type)

        image = cv2.GaussianBlur(image, (3, 3), 0)
        return image, mask

    def generate_dataset(
        self,
        num_samples_per_class: int = 5,
        output_dir: Optional[str] = None
    ) -> Tuple[List[np.ndarray], List[np.ndarray], List[int]]:
        """Generate full dataset."""
        images, masks, labels = [], [], []

        for tissue_type in range(4):
            for _ in range(num_samples_per_class):
                img, mask = self.generate_image_and_mask(tissue_type)
                images.append(img)
                masks.append(mask)
                labels.append(tissue_type)

                if output_dir:
                    self._save_sample(output_dir, tissue_type, img, mask)

        return images, masks, labels

    def _save_sample(self, output_dir: str, tissue_type: int,
                     image: np.ndarray, mask: np.ndarray) -> None:
        """Save image and mask to disk."""
        tissue_names = ['tumor', 'inflammatory', 'stroma', 'necrosis']
        tissue_dir = Path(output_dir) / tissue_names[tissue_type]
        tissue_dir.mkdir(parents=True, exist_ok=True)

        idx = len(list(tissue_dir.glob("image_*.png")))
        image_bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

        cv2.imwrite(str(tissue_dir / f"image_{idx:03d}.png"), image_bgr)
        cv2.imwrite(str(tissue_dir / f"mask_{idx:03d}.png"), mask)


def generate_mock_dataset(
    output_dir: str = "data/mock_dataset",
    num_samples_per_class: int = 20,
    image_size: int = 256
):
    """Convenience function to generate entire dataset."""
    print(f"Generating mock H&E dataset ({num_samples_per_class} samples/class)")

    generator = SyntheticHEImageGenerator(image_size=image_size)
    images, masks, labels = generator.generate_dataset(
        num_samples_per_class=num_samples_per_class,
        output_dir=output_dir
    )

    print(f"Generated {len(images)} samples at {output_dir}")
    return images, masks, labels


if __name__ == "__main__":
    print("Testing synthetic H&E generator...\n")

    generator = SyntheticHEImageGenerator()

    for t, name in enumerate(["Tumor", "Inflammatory", "Stroma", "Necrosis"]):
        img, msk = generator.generate_image_and_mask(t)
        print(f"{name}: Image {img.shape}, Mask pixels {msk.sum() // 255}")

    images, masks, labels = generate_mock_dataset(
        output_dir="data/mock_dataset",
        num_samples_per_class=5
    )

    print("\nDataset generation complete.")