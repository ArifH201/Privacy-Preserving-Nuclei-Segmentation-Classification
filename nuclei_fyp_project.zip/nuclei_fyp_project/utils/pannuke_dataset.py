import numpy as np
import torch
from torch.utils.data import Dataset

class PanNukeDataset(Dataset):

    def __init__(self, images_path, masks_path, types_path):

        # load images, masks and classification labels
        self.images = np.load(images_path, mmap_mode='r')
        self.masks = np.load(masks_path, mmap_mode='r')
        self.types = np.load(types_path)

        # convert tissue names → numeric labels
        self.label_map = {
        "Breast":0,
        "Cervix":1,
        "Ovarian":2,
        "Uterus":3,
        "Colon":4,
        "Stomach":5,
        "Esophagus":6,
        "Pancreatic":7,
        "Bile-duct":8,
        "Lung":9,
        "HeadNeck":10,
        "Skin":11,
        "Thyroid":12,
        "Kidney":13,
        "Bladder":14,
        "Prostate":15,
        "Testis":16,
        "Liver":17,
        "Adrenal_gland":18
        }

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):

        image = self.images[idx]
        mask = self.masks[idx]
        tissue_type = self.types[idx]

        # convert string label → number
        tissue_type = self.label_map[str(tissue_type)]

        # convert one-hot mask (256,256,6) → class map (256,256)
        mask = np.argmax(mask, axis=-1)

        # normalize image
        image = image.astype(np.float32) / 255.0

        # convert to tensors
        image = torch.from_numpy(image).permute(2,0,1)
        mask = torch.tensor(mask).long()
        tissue_type = torch.tensor(tissue_type).long()

        return image, mask, tissue_type