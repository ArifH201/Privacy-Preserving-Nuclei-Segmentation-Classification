"""
Image Processing Utilities for Nuclei Segmentation and Classification.

Provides utilities for:
- Loading & preprocessing H&E histopathology images
- Patch extraction
- Data augmentation
- PyTorch Dataset support
"""

import numpy as np
import cv2
from typing import Tuple, List, Optional
from pathlib import Path
import torch
from torch.utils.data import Dataset
import albumentations as A
from albumentations.pytorch import ToTensorV2


# --------------------------------------------------
# Image Processing Utilities
# --------------------------------------------------

class HistologyImageProcessor:
    """Process and prepare histology images."""

    def __init__(self, patch_size: int = 256, stride: Optional[int] = None):
        self.patch_size = patch_size
        self.stride = stride if stride is not None else patch_size

    def extract_patches(
        self, image: np.ndarray, mask: np.ndarray
    ) -> Tuple[List[np.ndarray], List[np.ndarray]]:
        """Extract image & mask patches."""
        h, w = image.shape[:2]
        image_patches, mask_patches = [], []

        for y in range(0, h - self.patch_size + 1, self.stride):
            for x in range(0, w - self.patch_size + 1, self.stride):
                img_patch = image[y:y+self.patch_size, x:x+self.patch_size]
                mask_patch = mask[y:y+self.patch_size, x:x+self.patch_size]

                if img_patch.shape[:2] == (self.patch_size, self.patch_size):
                    image_patches.append(img_patch)
                    mask_patches.append(mask_patch)

        return image_patches, mask_patches

    def resize_image(self, image: np.ndarray, size: int) -> np.ndarray:
        return cv2.resize(image, (size, size), interpolation=cv2.INTER_LINEAR)

    def normalize_uint8_to_float(self, image: np.ndarray) -> np.ndarray:
        return image.astype(np.float32) / 255.0

    def normalize_float_to_uint8(self, image: np.ndarray) -> np.ndarray:
        image = np.clip(image, 0, 1)
        return (image * 255).astype(np.uint8)


# --------------------------------------------------
# PyTorch Dataset
# --------------------------------------------------

class HistologyDataset(Dataset):
    """
    PyTorch Dataset for histology images, masks, and class labels.
    """

    def __init__(
        self,
        image_paths: List[str],
        mask_paths: List[str],
        class_labels: List[int],
        image_size: int = 256,
        augment: bool = False,
        normalize: bool = True
    ):
        assert len(image_paths) == len(mask_paths) == len(class_labels), \
            "Image, mask, and label lists must have the same length"

        self.image_paths = image_paths
        self.mask_paths = mask_paths
        self.class_labels = class_labels
        self.image_size = image_size

        # Build transform pipeline
        transforms = [A.Resize(image_size, image_size)]

        if augment:
            transforms += [
                A.HorizontalFlip(p=0.5),
                A.VerticalFlip(p=0.5),
                A.Rotate(limit=45, p=0.5),
                A.RandomBrightnessContrast(p=0.3),
                A.GaussNoise(p=0.1),
            ]

        if normalize:
            transforms.append(
                A.Normalize(
                    mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]
                )
            )

        transforms.append(ToTensorV2())

        self.transform = A.Compose(transforms, is_check_shapes=False)

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> dict:
        # Load image
        image = cv2.imread(self.image_paths[idx])
        if image is None:
            raise FileNotFoundError(f"Image not found: {self.image_paths[idx]}")
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Load mask
        mask = cv2.imread(self.mask_paths[idx], cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise FileNotFoundError(f"Mask not found: {self.mask_paths[idx]}")

        # Apply transforms
        augmented = self.transform(image=image, mask=mask)
        image = augmented["image"]          # Tensor [3, H, W]
        mask = augmented["mask"]            # Tensor [H, W]

        # Normalize mask to [0,1] and add channel dim
        mask = mask.float() / 255.0
        mask = mask.unsqueeze(0)             # [1, H, W]

        label = torch.tensor(self.class_labels[idx], dtype=torch.long)

        return {
            "image": image,
            "mask": mask,
            "label": label
        }


# --------------------------------------------------
# Standalone Pipelines
# --------------------------------------------------

def create_augmentation_pipeline(image_size: int = 256) -> A.Compose:
    """Training augmentation pipeline."""
    return A.Compose([
        A.Resize(image_size, image_size),
        A.HorizontalFlip(p=0.5),
        A.VerticalFlip(p=0.5),
        A.Rotate(limit=45, p=0.5),
        A.RandomBrightnessContrast(p=0.3),
        A.GaussNoise(p=0.1),
        A.GaussianBlur(p=0.1),
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ], is_check_shapes=False)


def create_validation_pipeline(image_size: int = 256) -> A.Compose:
    """Validation / test pipeline."""
    return A.Compose([
        A.Resize(image_size, image_size),
        A.Normalize(mean=[0.485, 0.456, 0.406],
                    std=[0.229, 0.224, 0.225]),
        ToTensorV2(),
    ], is_check_shapes=False)