"""
Reinhard Stain Normalization for H&E Histopathology Images.

Addresses color and intensity variation across tissue samples
acquired from different hospitals and staining protocols.

Reference:
Reinhard et al. (2001) - Color Transfer Between Images
"""

import numpy as np
import cv2
from typing import Optional


# --------------------------------------------------
# Core Reinhard Normalizer
# --------------------------------------------------

class ReinhardNormalizer:
    """
    Reinhard stain normalization for H&E histopathology images.
    """

    def __init__(self, target_image: Optional[np.ndarray] = None):
        self.target_mean = None
        self.target_std = None

        if target_image is not None:
            self.fit(target_image)
        else:
            self._set_default_reference()

    def _set_default_reference(self) -> None:
        """Set default LAB statistics for H&E images."""
        self.target_mean = np.array([50.0, 128.0, 128.0], dtype=np.float32)
        self.target_std = np.array([20.0, 10.0, 10.0], dtype=np.float32)

    def fit(self, target_image: np.ndarray) -> None:
        """Learn reference LAB statistics from a target image."""
        if target_image.ndim != 3 or target_image.shape[2] != 3:
            raise ValueError(f"Expected RGB image, got {target_image.shape}")

        target_image = target_image.astype(np.uint8)
        lab = cv2.cvtColor(target_image, cv2.COLOR_RGB2LAB).astype(np.float32)

        self.target_mean = lab.mean(axis=(0, 1))
        self.target_std = lab.std(axis=(0, 1))
        self.target_std[self.target_std == 0] = 1.0

    def normalize(self, source_image: np.ndarray) -> np.ndarray:
        """Normalize source image using Reinhard method."""
        if source_image.ndim != 3 or source_image.shape[2] != 3:
            raise ValueError(f"Expected RGB image, got {source_image.shape}")

        if self.target_mean is None or self.target_std is None:
            raise RuntimeError("Normalizer not fitted.")

        source_image = source_image.astype(np.uint8)

        lab = cv2.cvtColor(source_image, cv2.COLOR_RGB2LAB).astype(np.float32)

        source_mean = lab.mean(axis=(0, 1))
        source_std = lab.std(axis=(0, 1))
        source_std[source_std == 0] = 1.0

        normalized = (lab - source_mean) * (self.target_std / source_std) + self.target_mean

        # Clip LAB ranges safely (OpenCV format)
        normalized[:, :, 0] = np.clip(normalized[:, :, 0], 0, 255)   # L
        normalized[:, :, 1] = np.clip(normalized[:, :, 1], 0, 255)   # a
        normalized[:, :, 2] = np.clip(normalized[:, :, 2], 0, 255)   # b

        normalized = normalized.astype(np.uint8)
        rgb = cv2.cvtColor(normalized, cv2.COLOR_LAB2RGB)

        return rgb

    def __call__(self, image: np.ndarray) -> np.ndarray:
        return self.normalize(image)


# --------------------------------------------------
# Adaptive Reinhard Normalizer (Online)
# --------------------------------------------------

class AdaptiveReinhardNormalizer(ReinhardNormalizer):
    """
    Adaptive Reinhard normalizer using batch statistics.
    Useful when reference image is unavailable.
    """

    def __init__(self, batch_size: int = 10):
        super().__init__()
        self.batch_size = batch_size
        self._buffer = []

    def accumulate(self, image: np.ndarray) -> None:
        """Accumulate images and update reference statistics."""
        image = image.astype(np.uint8)
        lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB).astype(np.float32)
        self._buffer.append(lab)

        if len(self._buffer) >= self.batch_size:
            means = np.array([img.mean(axis=(0, 1)) for img in self._buffer])
            stds = np.array([img.std(axis=(0, 1)) for img in self._buffer])

            self.target_mean = means.mean(axis=0)
            self.target_std = stds.mean(axis=0)
            self.target_std[self.target_std == 0] = 1.0

            self._buffer.clear()

    def reset(self) -> None:
        """Reset buffer and restore default reference."""
        self._buffer.clear()
        self._set_default_reference()


# --------------------------------------------------
# Batch Normalization Utility
# --------------------------------------------------

def normalize_batch(
    images: np.ndarray,
    reference_image: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Normalize a batch of RGB images using Reinhard normalization.

    Args:
        images: Array of shape (N, H, W, 3), uint8 RGB
        reference_image: Optional reference image

    Returns:
        Normalized images (uint8, RGB)
    """
    if images.ndim != 4 or images.shape[-1] != 3:
        raise ValueError("Expected images of shape (N, H, W, 3)")

    normalizer = ReinhardNormalizer(reference_image)
    normalized = np.empty_like(images)

    for i in range(images.shape[0]):
        normalized[i] = normalizer.normalize(images[i])

    return normalized


# --------------------------------------------------
# Example Usage
# --------------------------------------------------

if __name__ == "__main__":
    print("Reinhard Stain Normalization Test")
    print("=" * 50)

    test_image = np.random.randint(40, 200, size=(256, 256, 3), dtype=np.uint8)

    normalizer = ReinhardNormalizer()
    output = normalizer.normalize(test_image)

    print("Input shape :", test_image.shape)
    print("Output shape:", output.shape)
    print("Normalization successful ✔")